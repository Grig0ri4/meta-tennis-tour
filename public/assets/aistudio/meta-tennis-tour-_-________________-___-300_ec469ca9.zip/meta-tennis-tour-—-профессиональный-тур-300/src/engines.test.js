import test from 'node:test';
import assert from 'node:assert/strict';

import { PRESERVED_BASE, CLEAN_UNIQUE_POOL, buildInitial300Players } from '../data/players.js';
import { FULL_CALENDAR_TEMPLATE, getTourneyDateRange } from '../data/tournaments.js';
import { createTournamentDraw, calculateGroupStandings } from './drawEngine.js';
import {
  formatTennisScore,
  computeSimMatchScores,
  parseAndValidateScoreString,
  advanceWinnerInDraw,
  getHeadToHeadAnalytics
} from './matchEngine.js';
import {
  calculateAgeNum,
  sortAndRankPlayers,
  applyTournamentPointsToPlayers,
  createTop50Snapshot
} from './rankingEngine.js';
import {
  getRetirementProbability,
  processEndOfSeasonRetirements
} from './retirementEngine.js';

test('Раздел 2: База 300 игроков сохраняет первые 140 игроков и содержит уникальные имена на латинице без цифр для 141-300', () => {
  const players = buildInitial300Players();
  assert.equal(players.length, 300);

  // Первые 140 неприкосновенны
  assert.equal(players[0].id, 'p_1');
  assert.equal(players[0].name, 'Istep Fofol');
  assert.equal(players[0].flag, 'SLO');
  assert.equal(players[0].birthDate, '1988-04-20');

  assert.equal(players[1].name, 'Will Wentra');
  assert.equal(players[2].name, 'Max Kyupan');
  assert.equal(players[3].name, 'Puddy Mexalino');
  assert.equal(players[5].name, 'Gary Riffay');
  assert.equal(players[139].name, 'Lars Nielsen');

  // Проверка 141..300: нет цифр в имени, уникальные имена, возраст 17..37 в 2024 году
  const names141to300 = new Set();
  for (let i = 140; i < 300; i++) {
    const p = players[i];
    assert.equal(/\d/.test(p.name), false, `Имя ${p.name} не должно содержать цифр`);
    assert.equal(names141to300.has(p.name.toLowerCase()), false, `Имя ${p.name} должно быть уникальным`);
    names141to300.add(p.name.toLowerCase());

    const age = calculateAgeNum(p.birthDate, '2024-06-01');
    assert.ok(age >= 17 && age <= 37, `Возраст игрока ${p.name} (${age}) должен быть от 17 до 37 лет`);
  }
});

test('Раздел 2: Календарь содержит ровно 26 турниров с сохраненными названиями и покрытиями', () => {
  assert.equal(FULL_CALENDAR_TEMPLATE.length, 26);
  assert.equal(FULL_CALENDAR_TEMPLATE[0].name, 'Хьюстон Masters');
  assert.equal(FULL_CALENDAR_TEMPLATE[1].name, 'Cartom Calamb (ТБШ)');
  assert.equal(FULL_CALENDAR_TEMPLATE[5].name, 'Александрия Masters');
  assert.equal(FULL_CALENDAR_TEMPLATE[10].name, 'Poland Open (ТБШ)');
  assert.equal(FULL_CALENDAR_TEMPLATE[14].name, 'Polovchis (ТБШ)');
  assert.equal(FULL_CALENDAR_TEMPLATE[18].name, 'Okeanskiy Open (ТБШ)');
  assert.equal(FULL_CALENDAR_TEMPLATE[25].name, 'World Tour Finals - Стокгольм (Топ-8)');
  assert.equal(getTourneyDateRange(FULL_CALENDAR_TEMPLATE[0], 2024), '02.01 - 11.01.2024');
});

test('Раздел 2: Относительный посев (ТБШ 1..32, Мастерс 1..16, ATP 500 1..8)', () => {
  const players = buildInitial300Players();

  // Мастерс 64 -> сеяные строго 1..16
  const mDraw = createTournamentDraw(FULL_CALENDAR_TEMPLATE[0], players).draw;
  const mSeeds = [];
  mDraw[0].forEach(m => {
    if (m.p1?.seedNum) mSeeds.push(m.p1.seedNum);
    if (m.p2?.seedNum) mSeeds.push(m.p2.seedNum);
  });
  mSeeds.sort((a, b) => a - b);
  assert.deepEqual(mSeeds, Array.from({ length: 16 }, (_, i) => i + 1));

  // ТБШ 128 -> сеяные строго 1..32
  const slamDraw = createTournamentDraw(FULL_CALENDAR_TEMPLATE[1], players).draw;
  const slamSeeds = [];
  slamDraw[0].forEach(m => {
    if (m.p1?.seedNum) slamSeeds.push(m.p1.seedNum);
    if (m.p2?.seedNum) slamSeeds.push(m.p2.seedNum);
  });
  slamSeeds.sort((a, b) => a - b);
  assert.deepEqual(slamSeeds, Array.from({ length: 32 }, (_, i) => i + 1));

  // ATP 500 -> сеяные строго 1..8
  const atp500Draw = createTournamentDraw(FULL_CALENDAR_TEMPLATE[2], players).draw;
  const seeds500 = [];
  atp500Draw[0].forEach(m => {
    if (m.p1?.seedNum) seeds500.push(m.p1.seedNum);
    if (m.p2?.seedNum) seeds500.push(m.p2.seedNum);
  });
  seeds500.sort((a, b) => a - b);
  assert.deepEqual(seeds500, Array.from({ length: 8 }, (_, i) => i + 1));
});

test('Раздел 2: Итоговый турнир (2 группы по 4, 6 матчей в группе, выход 1A vs 2B и 1B vs 2A)', () => {
  const players = buildInitial300Players();
  players.slice(0, 8).forEach((p, idx) => { p.racePoints = (8 - idx) * 1000; });

  const finalsTourney = FULL_CALENDAR_TEMPLATE[25];
  const { draw } = createTournamentDraw(finalsTourney, players);

  assert.equal(draw.length, 4);
  assert.equal(draw[0].length, 6); // 6 матчей в группе А
  assert.equal(draw[1].length, 6); // 6 матчей в группе Б

  // Симулируем все матчи в обеих группах
  draw[0].forEach((m, idx) => {
    const sim = computeSimMatchScores(m, 3, 1);
    advanceWinnerInDraw(draw, 'finals', 0, idx, sim.winner, sim.scores);
  });
  draw[1].forEach((m, idx) => {
    const sim = computeSimMatchScores(m, 3, 1);
    advanceWinnerInDraw(draw, 'finals', 1, idx, sim.winner, sim.scores);
  });

  const gA = calculateGroupStandings(draw[0]);
  const gB = calculateGroupStandings(draw[1]);

  // Проверяем полуфинальные пары: 1A vs 2B и 1B vs 2A
  assert.equal(draw[2][0].p1.id, gA[0].player.id);
  assert.equal(draw[2][0].p2.id, gB[1].player.id);
  assert.equal(draw[2][1].p1.id, gB[0].player.id);
  assert.equal(draw[2][1].p2.id, gA[1].player.id);
});

test('Раздел 2: Двойной рейтинг (52 недели с защитой очков и Live Race)', () => {
  const players = buildInitial300Players();
  const tourney = FULL_CALENDAR_TEMPLATE[2]; // ATP 500 (32)
  const { draw } = createTournamentDraw(tourney, players);

  // Проводим весь турнир
  for (let r = 0; r < draw.length; r++) {
    for (let m = 0; m < draw[r].length; m++) {
      const match = draw[r][m];
      const sim = computeSimMatchScores(match, 3, 1);
      advanceWinnerInDraw(draw, tourney.id, r, m, sim.winner, sim.scores);
    }
  }

  const champion = draw[draw.length - 1][0].winner;
  const champPlayer = players.find(p => p.id === champion.id);
  const initialPts = champPlayer.points;

  // Зададим ему защищаемые очки за прошлый год = 200
  champPlayer.tournamentPoints[tourney.id] = { 2023: 200 };

  applyTournamentPointsToPlayers(players, tourney, draw, 2024);
  sortAndRankPlayers(players, true);

  // Очки чемпиона за ATP 500 = 500. Итого: initialPts - 200 + 500 = initialPts + 300
  assert.equal(champPlayer.points, initialPts - 200 + 500);
  // В Live Race идет чистый заработок за сезон = 500
  assert.equal(champPlayer.racePoints, 500);
});

test('Раздел 3.1: Система завершения карьеры (защита Топ-50, шкала 37-42, генерация ньюгенов 17-23 лет с 20-45 очками)', () => {
  // Проверим вероятности
  assert.equal(getRetirementProbability(36, 120), 0);
  assert.equal(getRetirementProbability(39, 12), 0.075); // Топ-50 защищен (5-10%)
  assert.equal(getRetirementProbability(37, 80), 0.25);
  assert.equal(getRetirementProbability(38, 80), 0.50);
  assert.equal(getRetirementProbability(39, 80), 0.70);
  assert.equal(getRetirementProbability(40, 80), 0.85);
  assert.equal(getRetirementProbability(41, 80), 0.98);

  const players = buildInitial300Players();
  // Сделаем несколько ветеранов вне Топ-50 berusia 41 год, чтобы гарантировать уход при детерминированном RNG
  players[150].birthDate = '1983-02-10'; // 41 год в 2024
  players[151].birthDate = '1982-05-15'; // 42 года в 2024
  players[152].birthDate = '1984-03-10'; // 40 лет в 2024

  // Детерминированный генератор = 0.20 (уходят все с prob > 0.20, но Топ-50 с 0.075 остаются!)
  const { updatedPlayers, retiredThisYear, newgensThisYear } = processEndOfSeasonRetirements(
    players,
    2024,
    [],
    () => 0.20
  );

  // Общий пул обязан остаться ровно 300 игроков
  assert.equal(updatedPlayers.length, 300);
  assert.equal(retiredThisYear.length, newgensThisYear.length);
  assert.ok(retiredThisYear.length >= 3);

  // Никто из Топ-50 не ушел при rng = 0.20 (так как их порог 0.075)
  assert.equal(retiredThisYear.some(r => r.finalRank <= 50), false);

  // Проверим всех сгенерированных ньюгенов
  newgensThisYear.forEach(ng => {
    assert.equal(/\d/.test(ng.name), false, `Имя новичка ${ng.name} без цифр`);
    assert.ok(ng.points >= 20 && ng.points <= 45, `Очки новичка ${ng.points} в диапазоне 20-45`);
    assert.ok(ng.ageAtEntry >= 17 && ng.ageAtEntry <= 23, `Возраст новичка ${ng.ageAtEntry} в диапазоне 17-23`);
  });
});

test('Раздел 3.2 и 3.3: Срезы Топ-50 с динамикой и аналитика H2H с супер-тайбрейками', () => {
  const players = buildInitial300Players();
  const snap1 = createTop50Snapshot(players, '2024-01-29');
  assert.equal(snap1.length, 50);

  // Поменяем местами #1 и #2
  const tempPts = players[0].points;
  players[0].points = players[1].points - 100;
  players[1].points = tempPts + 100;
  sortAndRankPlayers(players, true);

  const snap2 = createTop50Snapshot(players, '2024-06-11', snap1);
  assert.equal(snap2[0].name, 'Will Wentra');
  assert.equal(snap2[0].rankDelta, 1); // Поднялся с #2 на #1 (+1)
  assert.equal(snap2[1].name, 'Istep Fofol');
  assert.equal(snap2[1].rankDelta, -1); // Опустился с #1 на #2 (-1)

  // Проверка парсера счета и супер-тайбрейков
  const parsed = parseAndValidateScoreString('6-4 6-7(4) 7-6(10)', 3);
  assert.equal(parsed.valid, true);
  assert.equal(parsed.p1WinsMatch, true);
  assert.equal(formatTennisScore(parsed.sets), '6-4  6-7<sup>4</sup>  7-6<sup>10</sup>');

  // Проверка аналитики H2H
  const mockDraw = [[{
    p1: players[0],
    p2: players[1],
    winner: players[0],
    score: ['6-4', '6-7(5)', '7-6(10)']
  }]];
  const h2h = getHeadToHeadAnalytics(
    players[0].id,
    players[1].id,
    [FULL_CALENDAR_TEMPLATE[0]],
    2024,
    (tId, yr) => (tId === 'm_1' && yr === 2024 ? mockDraw : null)
  );
  assert.equal(h2h.p1Wins, 1);
  assert.equal(h2h.p2Wins, 0);
  assert.equal(h2h.surfaceStats['Хард'][0], 1);
  assert.equal(h2h.history[0].scoreFormatted, '6-4  6-7<sup>5</sup>  7-6<sup>10</sup>');
});

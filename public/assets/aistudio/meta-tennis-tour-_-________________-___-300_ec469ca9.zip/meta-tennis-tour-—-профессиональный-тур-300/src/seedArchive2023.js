/**
 * Meta Tennis Tour — Инициализация архива сезона 2023 (seedArchive2023.js)
 * Гарантирует, что в Зале Славы (Архив Топ-50) с первой секунды доступен полноценный исторический сезон 2023:
 * - Все 5 срезов Топ-50 (после 1-го, 2-го, 3-го, 4-го ТБШ и Итоговый Топ-50 сезона) со сравнением динамики
 * - Все 26 турниров 2023 года с чемпионами, финалистами, счетом финала и полными сетками, доступными по кнопке «🔍 Вся сетка»
 */

import { createTournamentDraw, calculateGroupStandings } from './drawEngine.js';
import { computeSimMatchScores, advanceWinnerInDraw } from './matchEngine.js';
import { calculateAge } from './rankingEngine.js';

export function ensureDefault2023SeasonArchive(tournaments, players, seasonsHistory) {
  let needsSaveHistory = false;

  // Если архив 2023 года еще не создан или в нем нет полных 26 турниров и 5 снимков Топ-50
  if (
    !seasonsHistory['2023'] ||
    !seasonsHistory['2023'].tournamentsData ||
    seasonsHistory['2023'].tournamentsData.length < 26 ||
    !seasonsHistory['2023'].slamSnapshots ||
    !seasonsHistory['2023'].slamSnapshots['tbsh_1']
  ) {
    const top50Base = players.slice(0, 50);

    // Функция создания реалистичного среза Топ-50 с динамикой относительно предыдущего среза
    const buildHistoricalSnapshot = (dateStr, offsetSeed, prevList) => {
      const prevMap = {};
      if (prevList) {
        prevList.forEach(p => { prevMap[p.id] = p.rank; });
      }

      // Моделируем реалистичную борьбу за позиции внутри сезона 2023, чтобы на каждом срезе отображалась живая динамика ▲/▼
      const simulated = top50Base.map((p, idx) => {
        const rankWeight = idx < 5 ? 950 : (idx < 15 ? 380 : 140);
        const wave = Math.round(Math.sin((idx + 2) * (offsetSeed * 1.7)) * (offsetSeed === 5 ? 0 : rankWeight));
        return {
          id: p.id,
          name: p.name,
          flag: p.flag,
          birthDate: p.birthDate,
          points: Math.max(400, p.points + wave),
          baseRank: idx + 1
        };
      });

      if (offsetSeed < 5) {
        simulated.sort((a, b) => b.points - a.points);
      }

      return simulated.map((p, idx) => {
        const rank = idx + 1;
        const prevRank = prevMap[p.id] !== undefined ? prevMap[p.id] : p.baseRank;
        return {
          id: p.id,
          rank,
          name: p.name,
          flag: p.flag,
          points: p.points,
          birthDate: p.birthDate,
          age: calculateAge(p.birthDate, dateStr),
          rankDelta: prevRank - rank
        };
      });
    };

    const snapStart = top50Base.map((p, idx) => ({
      id: p.id,
      rank: idx + 1,
      name: p.name,
      flag: p.flag,
      points: p.points,
      birthDate: p.birthDate,
      age: calculateAge(p.birthDate, '2023-01-02'),
      rankDelta: 0
    }));

    const snap1 = buildHistoricalSnapshot('2023-01-29', 1, snapStart);
    const snap2 = buildHistoricalSnapshot('2023-06-11', 2, snap1);
    const snap3 = buildHistoricalSnapshot('2023-07-21', 3, snap2);
    const snap4 = buildHistoricalSnapshot('2023-09-10', 4, snap3);
    const snapEnd = buildHistoricalSnapshot('2023-11-25', 5, snap4);

    // Создаем или достраиваем полные сетки всех 26 турниров 2023 года
    const tourneys2023Data = [];

    // Чтобы у Top-8 игроков были очки для Итогового 2023
    const simPlayers2023 = players.map((p, i) => ({
      ...p,
      racePoints: Math.max(0, 6000 - i * 180)
    }));

    tournaments.forEach(t => {
      let draw2023 = null;
      try {
        draw2023 = JSON.parse(localStorage.getItem(`draw_${t.id}_2023`));
      } catch {
        draw2023 = null;
      }

      // Если сетки 2023 для этого турнира нет или финал не сыгран — генерируем и симулируем полностью
      const isComplete = draw2023 && draw2023.length > 0 && draw2023[draw2023.length - 1][0]?.winner;
      if (!isComplete) {
        const created = createTournamentDraw(t, simPlayers2023);
        draw2023 = created.draw;
        for (let r = 0; r < draw2023.length; r++) {
          for (let m = 0; m < draw2023[r].length; m++) {
            const match = draw2023[r][m];
            if (match.p1 && match.p2 && !match.winner) {
              const sim = computeSimMatchScores(match, t.bestOf);
              advanceWinnerInDraw(draw2023, t.id, r, m, sim.winner, sim.scores);
            }
          }
        }
        try {
          localStorage.setItem(`draw_${t.id}_2023`, JSON.stringify(draw2023));
        } catch (e) {
          // ignore quota error if any
        }
      }

      const finalM = draw2023[draw2023.length - 1][0];
      const winner = finalM?.winner || players[0];
      const runnerUp = (finalM && finalM.p1 && finalM.p2)
        ? (finalM.p1.id === winner.id ? finalM.p2 : finalM.p1)
        : players[1];
      const scoreStr = (finalM && finalM.score && finalM.score.length > 0)
        ? finalM.score.join(' ')
        : '6-4 6-3';

      tourneys2023Data.push({
        id: t.id,
        name: t.name,
        type: t.type,
        surface: t.surface,
        winner: { id: winner.id, name: winner.name, flag: winner.flag },
        runnerUp: { id: runnerUp.id, name: runnerUp.name, flag: runnerUp.flag },
        score: scoreStr
      });
    });

    seasonsHistory['2023'] = {
      year: 2023,
      worldNumberOne: {
        id: players[0].id,
        name: players[0].name,
        flag: players[0].flag,
        points: players[0].points
      },
      seasonStartTop50: snapStart,
      slamSnapshots: {
        tbsh_1: {
          tourneyName: 'Cartom Calamb (ТБШ)',
          date: '2023-01-29',
          top50: snap1
        },
        tbsh_2: {
          tourneyName: 'Poland Open (ТБШ)',
          date: '2023-06-11',
          top50: snap2
        },
        tbsh_3: {
          tourneyName: 'Polovchis (ТБШ)',
          date: '2023-07-21',
          top50: snap3
        },
        tbsh_4: {
          tourneyName: 'Okeanskiy Open (ТБШ)',
          date: '2023-09-10',
          top50: snap4
        }
      },
      yearEndTop50: snapEnd,
      tournamentsData: tourneys2023Data
    };

    needsSaveHistory = true;
  }

  return needsSaveHistory;
}

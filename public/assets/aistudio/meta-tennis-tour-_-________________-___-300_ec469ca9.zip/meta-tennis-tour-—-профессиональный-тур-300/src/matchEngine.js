/**
 * Meta Tennis Tour — Движок матчей и Личных встреч H2H (matchEngine.js)
 * Генерация реалистичного теннисного счета, супер-тайбрейков, продвижение по сетке и полный аналитический блок H2H.
 */

import { calculateGroupStandings } from './drawEngine.js';
import { rNames128, rNames64, rNames32 } from '../data/tournaments.js';

export function formatTennisScore(scoreArray) {
  if (!scoreArray || scoreArray.length === 0) return '';
  const arr = Array.isArray(scoreArray) ? scoreArray : String(scoreArray).split(/\s+/);
  return arr.map(setStr => setStr.replace(/\((\d+)\)/g, '<sup>$1</sup>')).join('  ');
}

export function generateRealisticTennisSet(p1Wins, isDecidingSetTB = false, rankDiff = 0) {
  const roll = Math.random();
  let score = "";

  if (p1Wins) {
    if (roll < 0.04 || (rankDiff > 50 && roll < 0.12)) score = "6-0";
    else if (roll < 0.14 || (rankDiff > 40 && roll < 0.25)) score = "6-1";
    else if (roll < 0.35) score = "6-2";
    else if (roll < 0.60) score = "6-3";
    else if (roll < 0.80) score = "6-4";
    else if (roll < 0.90) score = "7-5";
    else {
      const loserPoints = isDecidingSetTB
        ? (Math.random() < 0.5 ? 8 + Math.floor(Math.random() * 3) : 6 + Math.floor(Math.random() * 2))
        : (2 + Math.floor(Math.random() * 6));
      score = `7-6(${loserPoints})`;
    }
  } else {
    if (roll < 0.04 || (rankDiff < -50 && roll < 0.12)) score = "0-6";
    else if (roll < 0.14 || (rankDiff < -40 && roll < 0.25)) score = "1-6";
    else if (roll < 0.35) score = "2-6";
    else if (roll < 0.60) score = "3-6";
    else if (roll < 0.80) score = "4-6";
    else if (roll < 0.90) score = "5-7";
    else {
      const loserPoints = isDecidingSetTB
        ? (Math.random() < 0.5 ? 8 + Math.floor(Math.random() * 3) : 6 + Math.floor(Math.random() * 2))
        : (2 + Math.floor(Math.random() * 6));
      score = `6-7(${loserPoints})`;
    }
  }
  return score;
}

export function computeSimMatchScores(m, bestOf = 3, forcedWinnerNumber = 0) {
  const req = bestOf === 5 ? 3 : 2;
  let p1W = 0;
  let p2W = 0;
  const scores = [];

  const r1 = (m.p1 && m.p1.rank) ? m.p1.rank : 100;
  const r2 = (m.p2 && m.p2.rank) ? m.p2.rank : 100;
  const rankDiff = r2 - r1;

  let p1Chance = r2 / (r1 + r2);
  if (isNaN(p1Chance)) p1Chance = 0.5;
  if (forcedWinnerNumber === 1) p1Chance = 1.0;
  if (forcedWinnerNumber === 2) p1Chance = 0.0;

  while (p1W < req && p2W < req) {
    const isFinalSetTB = (p1W === req - 1 && p2W === req - 1);
    const p1Takes = Math.random() < p1Chance;
    const setStr = generateRealisticTennisSet(p1Takes, isFinalSetTB, rankDiff);
    scores.push(setStr);

    if (p1Takes) p1W++;
    else p2W++;
  }

  return { winner: p1W > p2W ? m.p1 : m.p2, scores };
}

export function parseAndValidateScoreString(str, bestOf = 3) {
  const cleanStr = (str || '').trim();
  if (!cleanStr) {
    return { valid: false, error: 'Введите счет матча!' };
  }

  const sets = cleanStr.split(/\s+/);
  const req = bestOf === 5 ? 3 : 2;
  let p1W = 0;
  let p2W = 0;

  for (const s of sets) {
    const clean = s.replace(/\(\d+\)/g, '');
    const parts = clean.split('-');
    if (parts.length !== 2) {
      return { valid: false, error: `Некорректный формат сета: "${s}". Используйте формат 6-4 или 7-6(5).` };
    }
    const g1 = parseInt(parts[0], 10);
    const g2 = parseInt(parts[1], 10);
    if (isNaN(g1) || isNaN(g2) || g1 === g2) {
      return { valid: false, error: `В сете "${s}" должен быть определен победитель.` };
    }
    if (g1 > g2) p1W++;
    else if (g2 > g1) p2W++;
  }

  if (p1W < req && p2W < req) {
    return { valid: false, error: `Недостаточно выигранных сетов! Для победы требуется ${req} выигранных сета.` };
  }

  return {
    valid: true,
    sets,
    p1WinsMatch: p1W > p2W,
    p1W,
    p2W
  };
}

export function advanceWinnerInDraw(draw, tourneyId, rIdx, mIdx, winner, scoreArr) {
  const match = draw[rIdx][mIdx];
  match.winner = winner;
  match.score = scoreArr;

  if (tourneyId === 'finals') {
    const isGroupAComplete = draw[0].every(m => m.winner);
    const isGroupBComplete = draw[1].every(m => m.winner);
    if (isGroupAComplete && isGroupBComplete) {
      const groupAStats = calculateGroupStandings(draw[0]);
      const groupBStats = calculateGroupStandings(draw[1]);
      if (groupAStats.length >= 2 && groupBStats.length >= 2) {
        draw[2][0].p1 = groupAStats[0].player;
        draw[2][0].p2 = groupBStats[1].player;
        draw[2][1].p1 = groupBStats[0].player;
        draw[2][1].p2 = groupAStats[1].player;
      }
    }
    if (rIdx === 2) {
      if (mIdx === 0) draw[3][0].p1 = winner;
      else draw[3][0].p2 = winner;
    }
  } else {
    if (rIdx + 1 < draw.length) {
      const nextMIdx = Math.floor(mIdx / 2);
      if (mIdx % 2 === 0) draw[rIdx + 1][nextMIdx].p1 = winner;
      else draw[rIdx + 1][nextMIdx].p2 = winner;
    }
  }

  return draw;
}

export function getHeadToHeadAnalytics(p1Id, p2Id, tournaments, maxYear = 2032, storageGetter = null) {
  const history = [];
  const surfaceStats = {
    'Хард': [0, 0],
    'Грунт': [0, 0],
    'Трава': [0, 0],
    'Зал': [0, 0]
  };
  let p1Wins = 0;
  let p2Wins = 0;

  const getDraw = storageGetter || ((tId, yr) => {
    if (typeof localStorage === 'undefined') return null;
    try {
      return JSON.parse(localStorage.getItem(`draw_${tId}_${yr}`));
    } catch {
      return null;
    }
  });

  for (let y = 2023; y <= maxYear; y++) {
    (tournaments || []).forEach(t => {
      const drawData = getDraw(t.id, y);
      if (drawData && drawData.length > 0) {
        const rNames = (t.id === 'finals')
          ? ["Группа А", "Группа Б", "Полуфинал", "Финал"]
          : (drawData.length === 7 ? rNames128 : (drawData.length === 6 ? rNames64 : rNames32));

        drawData.forEach((round, rIdx) => {
          (round || []).forEach(m => {
            if (m && m.p1 && m.p2 && m.winner) {
              const matchFound = (m.p1.id === p1Id && m.p2.id === p2Id) || (m.p1.id === p2Id && m.p2.id === p1Id);
              if (matchFound) {
                const p1Won = m.winner.id === p1Id;
                if (p1Won) {
                  p1Wins++;
                  if (surfaceStats[t.surface]) surfaceStats[t.surface][0]++;
                } else {
                  p2Wins++;
                  if (surfaceStats[t.surface]) surfaceStats[t.surface][1]++;
                }

                // Нормализуем отображение счета с точки зрения победителя или как записано в матче
                const rawScore = m.score && m.score.length > 0 ? m.score : ['W/O'];
                history.push({
                  year: y,
                  tourneyId: t.id,
                  tourneyName: t.name,
                  surface: t.surface,
                  stage: (rNames[rIdx] || `Раунд ${rIdx + 1}`).replace(' 🏆', ''),
                  winnerId: m.winner.id,
                  winnerName: m.winner.name,
                  scoreArr: rawScore,
                  scoreFormatted: formatTennisScore(rawScore)
                });
              }
            }
          });
        });
      }
    });
  }

  return {
    p1Wins,
    p2Wins,
    surfaceStats,
    history: history.reverse() // Самые свежие матчи сверху
  };
}

if (typeof window !== 'undefined') {
  window.formatTennisScore = formatTennisScore;
  window.generateRealisticTennisSet = generateRealisticTennisSet;
  window.computeSimMatchScores = computeSimMatchScores;
  window.parseAndValidateScoreString = parseAndValidateScoreString;
  window.advanceWinnerInDraw = advanceWinnerInDraw;
  window.getHeadToHeadAnalytics = getHeadToHeadAnalytics;
}

/**
 * Meta Tennis Tour — Главный контроллер приложения (src/app.js)
 * Инициализация базы 300 игроков, 26 турниров, навигация по вкладкам, управление сезонами,
 * вызов жеребьевки, матчей, рейтингов, архива Зала Славы и системы завершения карьеры.
 */

import { PRESERVED_BASE, CLEAN_UNIQUE_POOL, buildInitial300Players } from '../data/players.js';
import {
  FULL_CALENDAR_TEMPLATE,
  rNames128,
  rNames64,
  rNames32,
  rNamesFinals,
  getTourneyDateRange
} from '../data/tournaments.js';
import {
  calculateGroupStandings,
  createTournamentDraw
} from './drawEngine.js';
import {
  formatTennisScore,
  computeSimMatchScores,
  parseAndValidateScoreString,
  advanceWinnerInDraw,
  getHeadToHeadAnalytics
} from './matchEngine.js';
import {
  POINTS_SCALE,
  calculateAge,
  getDefendingPoints,
  sortAndRankPlayers,
  applyTournamentPointsToPlayers,
  runBackgroundATP250Tournaments,
  createTop50Snapshot
} from './rankingEngine.js';
import {
  processEndOfSeasonRetirements
} from './retirementEngine.js';
import {
  ensureDefault2023SeasonArchive
} from './seedArchive2023.js';

// --- ГЛОБАЛЬНОЕ СОСТОЯНИЕ ТУРА ---
let currentTourYear = parseInt(localStorage.getItem('meta_tour_year_v6'), 10) || 2024;
let currentTourDateStr = localStorage.getItem('meta_tour_date_v6') || `${currentTourYear}-01-02`;
let activeTourneyId = localStorage.getItem('meta_active_tourney_v6') || 'm_1';
let viewingYear = currentTourYear;

let tournaments = JSON.parse(localStorage.getItem('meta_tournaments_v7')) || null;
let players = JSON.parse(localStorage.getItem('meta_players_v6')) || [];
let seasonsHistory = JSON.parse(localStorage.getItem('meta_seasons_history_v6')) || {};
let retiredLegends = JSON.parse(localStorage.getItem('meta_retired_legends_v1')) || [];

let activeTourney = null;
let currentDraw = [];
let activeRoundIdx = 0;
let activeMatchScore = null;
let activeSnapshotKey = 'yearEnd';
let activeCompareMode = 'prev'; // 'prev' | 'start'
let activeHallSubtab = 'archive';
let toastTimeout = null;

export function showToast(messageHtml, durationMs = 4200) {
  const banner = document.getElementById('toastBanner');
  if (!banner) return;
  banner.innerHTML = messageHtml;
  banner.style.display = 'block';
  if (toastTimeout) clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    banner.style.display = 'none';
  }, durationMs);
}

// --- 1. ИНИЦИАЛИЗАЦИЯ И СОХРАНЕНИЕ ДАННЫХ ---
function initData() {
  if (!tournaments || tournaments.length < 26) {
    const savedOldTourneys = JSON.parse(localStorage.getItem('meta_tournaments_v6')) || [];
    tournaments = FULL_CALENDAR_TEMPLATE.map(t => {
      const old = savedOldTourneys.find(o => o.id === t.id);
      if (old) return { ...t, name: old.name, surface: old.surface };
      return { ...t };
    });
    saveTournaments();
  }

  if (!players || players.length < 300) {
    if (players.length < 140) {
      players = buildInitial300Players();
    } else {
      // Достраиваем до 300 с чистыми именами без цифр
      const default300 = buildInitial300Players();
      const existingNames = new Set(players.slice(0, 140).map(p => p.name.toLowerCase()));
      let poolIndex = 0;

      for (let i = 140; i < players.length; i++) {
        const p = players[i];
        if (/\d/.test(p.name) || existingNames.has(p.name.toLowerCase())) {
          while (poolIndex < CLEAN_UNIQUE_POOL.length && existingNames.has(CLEAN_UNIQUE_POOL[poolIndex].name.toLowerCase())) {
            poolIndex++;
          }
          if (poolIndex < CLEAN_UNIQUE_POOL.length) {
            p.name = CLEAN_UNIQUE_POOL[poolIndex].name;
            p.flag = CLEAN_UNIQUE_POOL[poolIndex].flag;
            p.birthDate = CLEAN_UNIQUE_POOL[poolIndex].b;
            poolIndex++;
          }
        }
        existingNames.add(p.name.toLowerCase());
      }
      while (players.length < 300) {
        players.push(default300[players.length]);
      }
    }
  } else {
    // Гарантируем, что первые 140 игроков имеют свои оригинальные имена и даты рождения, а 141-300 не имеют цифр
    for (let i = 0; i < 140; i++) {
      players[i].name = PRESERVED_BASE[i].name;
      players[i].flag = PRESERVED_BASE[i].flag;
      players[i].birthDate = PRESERVED_BASE[i].birthDate;
    }
    const existingNames = new Set(players.slice(0, 140).map(p => p.name.toLowerCase()));
    let poolIndex = 0;
    for (let i = 140; i < players.length; i++) {
      const p = players[i];
      if (!p.isNewgen && (/\d/.test(p.name) || existingNames.has(p.name.toLowerCase()))) {
        while (poolIndex < CLEAN_UNIQUE_POOL.length && existingNames.has(CLEAN_UNIQUE_POOL[poolIndex].name.toLowerCase())) {
          poolIndex++;
        }
        if (poolIndex < CLEAN_UNIQUE_POOL.length) {
          p.name = CLEAN_UNIQUE_POOL[poolIndex].name;
          p.flag = CLEAN_UNIQUE_POOL[poolIndex].flag;
          p.birthDate = CLEAN_UNIQUE_POOL[poolIndex].b;
          poolIndex++;
        }
      }
      existingNames.add(p.name.toLowerCase());
    }
  }

  players.forEach((p, idx) => {
    if (!p.tournamentPoints) p.tournamentPoints = {};
    if (p.rankChange === undefined) p.rankChange = 0;
    if (p.racePoints === undefined) p.racePoints = 0;
    if (!p.bestRank) p.bestRank = p.rank || (idx + 1);
    if (p.seasonsPlayed === undefined) p.seasonsPlayed = 1;
    if (!p.seasonStartRank) p.seasonStartRank = p.rank || (idx + 1);
  });

  // Создаём полный архив 2023 года (со всеми 5 срезами Топ-50 и сетками 26 турниров), если он ещё не заполнен
  const archiveUpdated = ensureDefault2023SeasonArchive(tournaments, players, seasonsHistory);
  if (archiveUpdated) {
    saveHistory();
  }

  backfill2023HistoryFromDraws();

  // Авто-проверка синхронизации очков
  if (!localStorage.getItem('meta_repair_applied_v4')) {
    repairOvercountedPoints();
    localStorage.setItem('meta_repair_applied_v4', 'true');
  }

  savePlayers(false);
}

function recordPoints(playerId, tourneyId, year, pts) {
  const p = players.find(x => x.id === playerId);
  if (p) {
    if (!p.tournamentPoints) p.tournamentPoints = {};
    if (!p.tournamentPoints[tourneyId]) p.tournamentPoints[tourneyId] = {};
    p.tournamentPoints[tourneyId][year] = pts;
  }
}

function backfill2023HistoryFromDraws() {
  tournaments.forEach(t => {
    let drawData = null;
    try {
      drawData = JSON.parse(localStorage.getItem(`draw_${t.id}_2023`));
    } catch {
      drawData = null;
    }
    if (drawData && drawData.length > 0) {
      const ptsMap = POINTS_SCALE[t.size] || POINTS_SCALE[32];

      if (t.id === 'finals') {
        if (drawData[0] && drawData[1]) {
          const gA = calculateGroupStandings(drawData[0]);
          const gB = calculateGroupStandings(drawData[1]);
          [...gA, ...gB].forEach(st => {
            recordPoints(st.player.id, t.id, 2023, st.wins * 200);
          });
        }
        const finalM = drawData[drawData.length - 1][0];
        if (finalM && finalM.winner && finalM.p1 && finalM.p2) {
          const winId = finalM.winner.id;
          const losId = (finalM.p1.id === winId) ? finalM.p2.id : finalM.p1.id;
          const winBase = getDefendingPoints(players.find(p => p.id === winId), t.id, 2024);
          const losBase = getDefendingPoints(players.find(p => p.id === losId), t.id, 2024);
          recordPoints(winId, t.id, 2023, winBase + 900);
          recordPoints(losId, t.id, 2023, losBase + 400);
        }
      } else {
        drawData.forEach((round, rIdx) => {
          round.forEach(m => {
            if (m && m.winner) {
              const loserId = (m.p1 && m.winner.id === m.p1.id) ? (m.p2 ? m.p2.id : null) : (m.p1 ? m.p1.id : null);
              if (loserId) recordPoints(loserId, t.id, 2023, ptsMap[rIdx]);
            }
          });
        });
        const finalM = drawData[drawData.length - 1][0];
        if (finalM && finalM.winner) {
          recordPoints(finalM.winner.id, t.id, 2023, ptsMap[ptsMap.length - 1]);
        }
      }
    }
  });
}

function repairOvercountedPoints() {
  const exactEarned = {};
  players.forEach(p => { exactEarned[p.id] = 0; });

  tournaments.forEach(t => {
    let drawCurr = null;
    try {
      drawCurr = JSON.parse(localStorage.getItem(`draw_${t.id}_${currentTourYear}`));
    } catch {
      drawCurr = null;
    }
    if (drawCurr && drawCurr.length > 0) {
      const finalM = drawCurr[drawCurr.length - 1][0];
      if (finalM && finalM.winner) {
        const scale = POINTS_SCALE[t.size] || POINTS_SCALE[32];
        if (t.id === 'finals') {
          const gA = calculateGroupStandings(drawCurr[0]);
          const gB = calculateGroupStandings(drawCurr[1]);
          [...gA, ...gB].forEach(st => {
            exactEarned[st.player.id] = (exactEarned[st.player.id] || 0) + st.wins * 200;
          });
          const winId = finalM.winner.id;
          const losId = (finalM.p1.id === winId) ? finalM.p2.id : finalM.p1.id;
          exactEarned[winId] = (exactEarned[winId] || 0) + 900;
          exactEarned[losId] = (exactEarned[losId] || 0) + 400;
        } else {
          drawCurr.forEach((round, rIdx) => {
            round.forEach(m => {
              if (m && m.winner) {
                const loserId = (m.p1 && m.winner.id === m.p1.id) ? (m.p2 ? m.p2.id : null) : (m.p1 ? m.p1.id : null);
                if (loserId) exactEarned[loserId] = (exactEarned[loserId] || 0) + scale[rIdx];
              }
            });
          });
          exactEarned[finalM.winner.id] = (exactEarned[finalM.winner.id] || 0) + scale[scale.length - 1];
        }
      }
    }
  });

  const prevYear = currentTourYear - 1;
  const endPrevData = seasonsHistory[prevYear]?.yearEndTop50 || [];
  const basePrevMap = {};
  endPrevData.forEach(p => { basePrevMap[p.id] = p.points; });

  players.forEach(p => {
    const earned = exactEarned[p.id] || 0;
    p.racePoints = earned;

    if (basePrevMap[p.id]) {
      let defTotal = 0;
      tournaments.forEach(t => {
        const drawCurr = JSON.parse(localStorage.getItem(`draw_${t.id}_${currentTourYear}`));
        if (drawCurr && drawCurr[drawCurr.length - 1][0]?.winner) {
          defTotal += (p.tournamentPoints?.[t.id]?.[prevYear] || 0);
        }
      });
      p.points = Math.max(15, basePrevMap[p.id] - defTotal + earned);
    }
  });

  savePlayers(false);
}

export function manualRepairPoints() {
  repairOvercountedPoints();
  initUI();
  renderPlayersTable();
  renderRaceTable();
  showToast('✅ Очки всех игроков синхронизированы строго по завершенным сеткам текущего сезона.');
}

function savePlayers(updateRankChange = false) {
  sortAndRankPlayers(players, updateRankChange);
  localStorage.setItem('meta_players_v6', JSON.stringify(players));
}

function saveTournaments() {
  localStorage.setItem('meta_tournaments_v7', JSON.stringify(tournaments));
}

function saveHistory() {
  localStorage.setItem('meta_seasons_history_v6', JSON.stringify(seasonsHistory));
}

function saveRetiredLegends() {
  localStorage.setItem('meta_retired_legends_v1', JSON.stringify(retiredLegends));
}

function saveDate() {
  localStorage.setItem('meta_tour_year_v6', String(currentTourYear));
  localStorage.setItem('meta_tour_date_v6', currentTourDateStr);
  if (activeTourney) {
    localStorage.setItem('meta_active_tourney_v6', activeTourney.id);
  }
}

function saveDraw() {
  localStorage.setItem(`draw_${activeTourney.id}_${viewingYear}`, JSON.stringify(currentDraw));
}

function formatDateDisplay(dateStr) {
  const d = new Date(dateStr);
  const months = ["Января", "Февраля", "Марта", "Апреля", "Мая", "Июня", "Июля", "Августа", "Сентября", "Октября", "Ноября", "Декабря"];
  const day = String(d.getDate()).padStart(2, '0');
  return `${day} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

// --- 2. UI ИНИЦИАЛИЗАЦИЯ И НАВИГАЦИЯ ---
export function initUI() {
  activeTourney = tournaments.find(t => t.id === activeTourneyId) || tournaments[0];

  document.getElementById('currentYearDisplay').innerText = `Сезон ${currentTourYear}`;
  document.getElementById('currentDateDisplay').innerText = formatDateDisplay(currentTourDateStr);
  document.getElementById('raceYearHeader').innerText = String(currentTourYear);

  const drawYearSel = document.getElementById('drawYearSelect');
  let drawYearOpts = '';
  for (let y = 2023; y <= currentTourYear; y++) {
    drawYearOpts += `<option value="${y}" ${y === viewingYear ? 'selected' : ''}>Сезон ${y} ${y < currentTourYear ? '(Архив)' : ''}</option>`;
  }
  drawYearSel.innerHTML = drawYearOpts;

  const select = document.getElementById('tourneySelect');
  select.innerHTML = tournaments.map((t, idx) => `
    <option value="${t.id}" ${t.id === activeTourney.id ? 'selected' : ''}>
      #${idx + 1} ${t.name} (${t.type} · ${t.surface}) [${getTourneyDateRange(t, viewingYear)}]
    </option>
  `).join('');

  const calYearSelect = document.getElementById('calendarYearSelect');
  const prevSelectedCalYear = parseInt(calYearSelect.value, 10) || currentTourYear;
  let yearOptions = '';
  const maxCalYear = Math.max(2030, currentTourYear + 3);
  for (let y = 2023; y <= maxCalYear; y++) {
    yearOptions += `<option value="${y}" ${y === prevSelectedCalYear ? 'selected' : ''}>Сезон ${y}</option>`;
  }
  calYearSelect.innerHTML = yearOptions;

  loadCurrentTourney();
  renderCalendarTable();
  initHistoryUI();
}

export function changeDrawYear() {
  viewingYear = parseInt(document.getElementById('drawYearSelect').value, 10);
  // Обновим подписи дат в селекте турниров под выбранный год
  const select = document.getElementById('tourneySelect');
  const currentId = select.value;
  select.innerHTML = tournaments.map((t, idx) => `
    <option value="${t.id}" ${t.id === currentId ? 'selected' : ''}>
      #${idx + 1} ${t.name} (${t.type} · ${t.surface}) [${getTourneyDateRange(t, viewingYear)}]
    </option>
  `).join('');
  loadCurrentTourney();
}

export function loadCurrentTourney() {
  const id = document.getElementById('tourneySelect').value;
  activeTourney = tournaments.find(t => t.id === id) || tournaments[0];
  activeTourneyId = activeTourney.id;
  saveDate();

  currentDraw = JSON.parse(localStorage.getItem(`draw_${activeTourney.id}_${viewingYear}`)) || [];
  activeRoundIdx = 0;

  const withdrawals = JSON.parse(localStorage.getItem(`withdrawals_${activeTourney.id}_${viewingYear}`)) || [];
  const noticeBox = document.getElementById('withdrawalsNotice');
  if (withdrawals.length > 0) {
    noticeBox.style.display = 'block';
    noticeBox.innerHTML = `⚠️ <b>Пропускают турнир (Отдых / Травма / График):</b> ${withdrawals.join(', ')}`;
  } else {
    noticeBox.style.display = 'none';
  }

  const bgReport = localStorage.getItem(`bg250_${activeTourney.id}_${viewingYear}`);
  const bgBox = document.getElementById('bg250Notice');
  if (bgReport) {
    bgBox.style.display = 'block';
    bgBox.innerHTML = bgReport;
  } else {
    bgBox.style.display = 'none';
  }

  const isHistoricalArchive = (viewingYear < currentTourYear);
  const isCompletedInCurrentYear = (viewingYear === currentTourYear && Boolean(activeTourney.completed));

  document.getElementById('btnMakeDraw').style.display = isHistoricalArchive ? 'none' : 'inline-block';
  document.getElementById('btnSimRound').style.display = isHistoricalArchive ? 'none' : 'inline-block';
  document.getElementById('btnSimAllTourney').style.display = isHistoricalArchive ? 'none' : 'inline-block';
  document.getElementById('btnResetDraw').style.display = isHistoricalArchive ? 'none' : 'inline-block';

  // НАДЕЖНАЯ ЗАЩИТА КНОПКИ «ЗАВЕРШИТЬ ТУРНИР» ОТ ДВОЙНОГО НАЖАТИЯ
  const btnFinish = document.getElementById('btnFinishTourney');
  if (isHistoricalArchive) {
    btnFinish.style.display = 'none';
  } else {
    btnFinish.style.display = 'inline-block';
    if (isCompletedInCurrentYear) {
      btnFinish.disabled = true;
      btnFinish.innerText = 'Турнир завершен ✅';
    } else {
      btnFinish.disabled = false;
      btnFinish.innerText = '🏆 Завершить турнир';
    }
  }

  renderRoundTabs();
  renderMatches();
  renderCalendarTable();
}

// --- 3. ЖЕРЕБЬЕВКА И СЕТКА ТУРНИРА ---
export function generateRealisticDraw() {
  if (viewingYear < currentTourYear) return;
  if (activeTourney.completed) {
    showToast('⚠️ Этот турнир уже завершен в текущем сезоне и очки начислены.');
    return;
  }

  const { draw, withdrawals } = createTournamentDraw(activeTourney, players);
  currentDraw = draw;
  activeRoundIdx = 0;

  if (withdrawals.length > 0) {
    localStorage.setItem(`withdrawals_${activeTourney.id}_${viewingYear}`, JSON.stringify(withdrawals));
    const noticeBox = document.getElementById('withdrawalsNotice');
    noticeBox.style.display = 'block';
    noticeBox.innerHTML = `⚠️ <b>Пропускают турнир (Отдых / Травма / График):</b> ${withdrawals.join(', ')}`;
  } else {
    localStorage.removeItem(`withdrawals_${activeTourney.id}_${viewingYear}`);
    document.getElementById('withdrawalsNotice').style.display = 'none';
  }

  activeTourney.completed = false;
  saveTournaments();
  saveDraw();
  renderRoundTabs();
  renderMatches();
}

export function resetCurrentDraw() {
  if (viewingYear < currentTourYear) return;
  if (activeTourney.completed) {
    showToast('⚠️ Завершенный турнир сезона нельзя сбросить после начисления очков.');
    return;
  }
  currentDraw = [];
  localStorage.removeItem(`draw_${activeTourney.id}_${viewingYear}`);
  localStorage.removeItem(`withdrawals_${activeTourney.id}_${viewingYear}`);
  document.getElementById('withdrawalsNotice').style.display = 'none';
  renderRoundTabs();
  renderMatches();
}

export function renderRoundTabs() {
  const container = document.getElementById('roundTabs');
  if (!currentDraw || currentDraw.length === 0) {
    container.innerHTML = '';
    return;
  }

  let names;
  if (activeTourney.id === 'finals') names = rNamesFinals;
  else if (currentDraw.length === 7) names = rNames128;
  else if (currentDraw.length === 6) names = rNames64;
  else names = rNames32;

  container.innerHTML = currentDraw.map((r, idx) => `
    <button type="button" role="tab" aria-selected="${idx === activeRoundIdx}" class="round-tab ${idx === activeRoundIdx ? 'active' : ''}" onclick="changeRound(${idx})">
      ${names[idx]}
    </button>
  `).join('');
}

export function changeRound(idx) {
  activeRoundIdx = idx;
  renderRoundTabs();
  renderMatches();
}

function getPlayerSeedOrEntryTag(p) {
  if (!p) return '';
  if (p.seedNum) return `<span class="seed-tag">(${p.seedNum})</span>`;
  if (p.entryTag) return `<span class="entry-tag">[${p.entryTag}]</span>`;
  return '';
}

export function renderMatches() {
  const container = document.getElementById('matchesContainer');
  const tablesContainer = document.getElementById('finalsGroupTablesContainer');
  container.innerHTML = '';

  if (!currentDraw || currentDraw.length === 0) {
    tablesContainer.style.display = 'none';
    container.innerHTML = `
      <div style="grid-column: 1/-1; text-align:center; padding: 54px 20px; color: var(--text-dim); background: var(--card-bg); border: 1px dashed var(--border); border-radius: 8px;">
        <div style="font-size: 15px; font-weight: 600; color: var(--text-main); margin-bottom: 6px;">Сетка турнира еще не сформирована</div>
        <div style="font-size: 13px; margin-bottom: 14px;">Нажмите <b>«🎲 Жеребьевка»</b>, чтобы сформировать турнирную сетку с учетом посева и рейтинга.</div>
        <button type="button" class="btn-green" onclick="generateRealisticDraw()">🎲 Провести жеребьевку</button>
      </div>
    `;
    return;
  }

  const refDateStr = viewingYear < currentTourYear ? `${viewingYear}-06-15` : currentTourDateStr;

  if (activeTourney.id === 'finals') {
    tablesContainer.style.display = 'block';
    const groupAStats = calculateGroupStandings(currentDraw[0]);
    const groupBStats = calculateGroupStandings(currentDraw[1]);

    function makeTableHtml(title, list) {
      return `
        <div style="flex: 1; min-width: 300px;">
          <h4 style="margin-bottom: 6px; color: var(--accent); font-size: 14px;">${title}</h4>
          <table class="finals-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Игрок</th>
                <th>Матчи</th>
                <th>Сеты</th>
                <th>Геймы</th>
              </tr>
            </thead>
            <tbody>
              ${list.map((st, i) => `
                <tr class="${i < 2 ? 'qualified-row' : ''}">
                  <td><b>${i + 1}</b></td>
                  <td>
                    ${st.player.flag} ${st.player.name}
                    <span class="player-age-tag">${calculateAge(st.player.birthDate, refDateStr)}</span>
                    ${i < 2 ? '<span style="color:var(--primary); font-size:11px; margin-left:4px;">· 1/2 финала</span>' : ''}
                  </td>
                  <td><b>${st.wins}</b> - ${st.losses}</td>
                  <td>${st.setsW}-${st.setsL}</td>
                  <td>${st.gamesW}-${st.gamesL}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    tablesContainer.innerHTML = `
      <div style="display: flex; gap: 16px; flex-wrap: wrap;">
        ${makeTableHtml('Таблица Группы А', groupAStats)}
        ${makeTableHtml('Таблица Группы Б', groupBStats)}
      </div>
    `;

    const isGroupAComplete = currentDraw[0].every(m => m.winner);
    const isGroupBComplete = currentDraw[1].every(m => m.winner);
    if (isGroupAComplete && isGroupBComplete && groupAStats.length >= 2 && groupBStats.length >= 2) {
      currentDraw[2][0].p1 = groupAStats[0].player;
      currentDraw[2][0].p2 = groupBStats[1].player;
      currentDraw[2][1].p1 = groupBStats[0].player;
      currentDraw[2][1].p2 = groupAStats[1].player;
    }
  } else {
    tablesContainer.style.display = 'none';
  }

  const matches = currentDraw[activeRoundIdx] || [];
  matches.forEach((m, idx) => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'match-card';
    card.setAttribute('aria-label', `Матч ${idx + 1}: ${m.p1 ? m.p1.name : 'TBD'} против ${m.p2 ? m.p2.name : 'TBD'}`);
    card.onclick = () => openScoreModal(activeRoundIdx, idx);

    const p1Win = m.winner && m.p1 && m.winner.id === m.p1.id;
    const p2Win = m.winner && m.p2 && m.winner.id === m.p2.id;
    const scoreHtml = m.score && m.score.length > 0
      ? formatTennisScore(m.score)
      : (m.winner ? 'W/O' : 'Ввести счет ✍️');

    card.innerHTML = `
      <div style="font-size: 11px; color: var(--text-dim); margin-bottom: 4px; display: flex; justify-content: space-between;">
        <span>${m.group ? m.group + ' · ' : ''}Матч #${idx + 1}</span>
        <span>${m.winner ? 'Завершен' : 'Ожидает'}</span>
      </div>
      <div class="match-player ${p1Win ? 'winner' : ''}">
        <div class="player-info">
          <span style="font-size: 11px; color: var(--text-dim); width: 32px;">${m.p1 ? m.p1.flag : ''}</span>
          <span class="player-name">${m.p1 ? m.p1.name : '—'}</span>
          <span class="player-age-tag">${m.p1 ? calculateAge(m.p1.birthDate, refDateStr) : ''}</span>
          ${getPlayerSeedOrEntryTag(m.p1)}
        </div>
      </div>
      <div class="match-player ${p2Win ? 'winner' : ''}">
        <div class="player-info">
          <span style="font-size: 11px; color: var(--text-dim); width: 32px;">${m.p2 ? m.p2.flag : ''}</span>
          <span class="player-name">${m.p2 ? m.p2.name : '—'}</span>
          <span class="player-age-tag">${m.p2 ? calculateAge(m.p2.birthDate, refDateStr) : ''}</span>
          ${getPlayerSeedOrEntryTag(m.p2)}
        </div>
      </div>
      <div class="match-score" style="text-align: right; margin-top: 6px;">${scoreHtml}</div>
    `;
    container.appendChild(card);
  });
}

// --- 4. ИНТЕРФЕЙС МАТЧА, ГЕНЕРАТОР СЧЕТА И ЛИЧНЫЕ ВСТРЕЧИ (H2H) ---
function getSurfaceTextClass(surf) {
  if (surf === 'Хард') return 'surface-text-hard';
  if (surf === 'Грунт') return 'surface-text-clay';
  if (surf === 'Трава') return 'surface-text-grass';
  return 'surface-text-indoor';
}

export function openScoreModal(rIdx, mIdx) {
  const match = currentDraw[rIdx]?.[mIdx];
  if (!match || !match.p1 || !match.p2) {
    showToast('⚠️ Участники этого матча еще не определены в сетке!');
    return;
  }

  activeMatchScore = { rIdx, mIdx, match };
  const errEl = document.getElementById('scoreInputError');
  if (errEl) errEl.style.display = 'none';

  // Полная аналитика очных встреч (H2H) по всем сезонам
  const h2h = getHeadToHeadAnalytics(match.p1.id, match.p2.id, tournaments, Math.max(currentTourYear, viewingYear));
  const refDateStr = viewingYear < currentTourYear ? `${viewingYear}-06-15` : currentTourDateStr;

  const p1Live = players.find(p => p.id === match.p1.id) || match.p1;
  const p2Live = players.find(p => p.id === match.p2.id) || match.p2;

  let h2hHtml = `
    <div class="h2h-players-banner">
      <div class="h2h-col">
        <div class="h2h-player-name">${match.p1.flag} ${match.p1.name}</div>
        <div class="h2h-meta">Ранг: #${p1Live.rank || match.p1.rank} · Возраст: ${calculateAge(match.p1.birthDate, refDateStr)}</div>
      </div>
      <div class="h2h-center-score">
        <div class="h2h-label">Очные встречи</div>
        <div class="h2h-big-score">${h2h.p1Wins} : ${h2h.p2Wins}</div>
      </div>
      <div class="h2h-col right">
        <div class="h2h-player-name">${match.p2.name} ${match.p2.flag}</div>
        <div class="h2h-meta">Ранг: #${p2Live.rank || match.p2.rank} · Возраст: ${calculateAge(match.p2.birthDate, refDateStr)}</div>
      </div>
    </div>

    <div class="h2h-surface-bar">
      <span>Хард: <b>${h2h.surfaceStats['Хард'][0]}-${h2h.surfaceStats['Хард'][1]}</b></span>
      <span aria-hidden="true">|</span>
      <span>Грунт: <b>${h2h.surfaceStats['Грунт'][0]}-${h2h.surfaceStats['Грунт'][1]}</b></span>
      <span aria-hidden="true">|</span>
      <span>Трава: <b>${h2h.surfaceStats['Трава'][0]}-${h2h.surfaceStats['Трава'][1]}</b></span>
      <span aria-hidden="true">|</span>
      <span>Зал: <b>${h2h.surfaceStats['Зал'][0]}-${h2h.surfaceStats['Зал'][1]}</b></span>
    </div>
  `;

  if (h2h.history.length === 0) {
    h2hHtml += `<div style="color: var(--text-dim); font-size: 12.5px; text-align: center; padding: 10px 0;">🎾 Ранее на турнирах не встречались (0 : 0). Это их первая очная дуэль!</div>`;
  } else {
    h2hHtml += `<div class="h2h-history-list">`;
    h2h.history.forEach(item => {
      const isP1Win = item.winnerId === match.p1.id;
      h2hHtml += `
        <div class="h2h-item">
          <div>
            <b>${item.year}</b> · ${item.tourneyName} (<span class="${getSurfaceTextClass(item.surface)}">${item.surface}</span>) · <span style="color:var(--text-dim);">${item.stage}</span>
          </div>
          <div style="white-space: nowrap;">
            <b style="color: ${isP1Win ? 'var(--primary)' : 'var(--accent)'}; margin-right: 8px;">${item.winnerName}</b>
            <span class="match-score">${item.scoreFormatted}</span>
          </div>
        </div>
      `;
    });
    h2hHtml += `</div>`;
  }

  document.getElementById('h2hContainer').innerHTML = h2hHtml;
  document.getElementById('quickScoreStr').value = match.score ? match.score.join(' ') : '';

  const isLocked = viewingYear < currentTourYear || activeTourney.completed;
  document.getElementById('btnSaveScore').disabled = isLocked;
  document.getElementById('btnGenScoreInput').disabled = isLocked;
  document.getElementById('btnInstantSimMatch').disabled = isLocked;

  document.getElementById('playerPresets').innerHTML = `
    <button type="button" class="player-win-btn" ${isLocked ? 'disabled' : ''} onclick="quickApplyWinner('${match.p1.id}')">
      <span>⚡ Победа: <b>${match.p1.name}</b></span>
      <span style="color: var(--primary);">Быстрый расчет</span>
    </button>
    <button type="button" class="player-win-btn" ${isLocked ? 'disabled' : ''} onclick="quickApplyWinner('${match.p2.id}')">
      <span>⚡ Победа: <b>${match.p2.name}</b></span>
      <span style="color: var(--primary);">Быстрый расчет</span>
    </button>
  `;

  document.getElementById('scoreModal').classList.add('open');
  setTimeout(() => document.getElementById('quickScoreStr').focus(), 60);
}

export function appendSetScore(scoreStr) {
  const input = document.getElementById('quickScoreStr');
  input.value = (input.value.trim() + ' ' + scoreStr).trim();
  input.focus();
}

export function clearScoreInput() {
  const input = document.getElementById('quickScoreStr');
  input.value = '';
  input.focus();
}

// Кнопка «🎲 Сгенерировать счет в поле» — подставляет реалистичный теннисный счет в инпут
export function generateRandomScoreToInput() {
  if (!activeMatchScore || !activeMatchScore.match) return;
  const sim = computeSimMatchScores(activeMatchScore.match, activeTourney ? activeTourney.bestOf : 3);
  document.getElementById('quickScoreStr').value = sim.scores.join(' ');
  const errEl = document.getElementById('scoreInputError');
  if (errEl) errEl.style.display = 'none';
}

// Кнопка «⚡ Рассчитать и применить» — моментально симулирует матч с учетом разницы в рейтинге и закрывает окно
export function instantSimulateMatch() {
  if (!activeMatchScore || !activeMatchScore.match) return;
  const sim = computeSimMatchScores(activeMatchScore.match, activeTourney ? activeTourney.bestOf : 3);
  applyMatchWinner(activeMatchScore.rIdx, activeMatchScore.mIdx, sim.winner, sim.scores);
  closeModal('scoreModal');
}

export function quickApplyWinner(winnerId) {
  if (!activeMatchScore || !activeMatchScore.match) return;
  const isP1 = activeMatchScore.match.p1.id === winnerId;
  const sim = computeSimMatchScores(activeMatchScore.match, activeTourney ? activeTourney.bestOf : 3, isP1 ? 1 : 2);
  applyMatchWinner(activeMatchScore.rIdx, activeMatchScore.mIdx, sim.winner, sim.scores);
  closeModal('scoreModal');
}

export function saveQuickStringScore() {
  if (!activeMatchScore) return;
  const str = document.getElementById('quickScoreStr').value;
  const validation = parseAndValidateScoreString(str, activeTourney ? activeTourney.bestOf : 3);
  const errEl = document.getElementById('scoreInputError');

  if (!validation.valid) {
    if (errEl) {
      errEl.innerText = validation.error;
      errEl.style.display = 'block';
    }
    return;
  }

  if (errEl) errEl.style.display = 'none';
  const winner = validation.p1WinsMatch ? activeMatchScore.match.p1 : activeMatchScore.match.p2;
  applyMatchWinner(activeMatchScore.rIdx, activeMatchScore.mIdx, winner, validation.sets);
  closeModal('scoreModal');
}

export function applyMatchWinner(rIdx, mIdx, winner, scoreArr) {
  advanceWinnerInDraw(currentDraw, activeTourney.id, rIdx, mIdx, winner, scoreArr);
  saveDraw();
  renderMatches();
}

export function autoSimulateRound() {
  if (viewingYear < currentTourYear || activeTourney.completed) return;
  if (!currentDraw || currentDraw.length === 0) {
    generateRealisticDraw();
  }
  currentDraw[activeRoundIdx].forEach((m, idx) => {
    if (!m.winner && m.p1 && m.p2) {
      const sim = computeSimMatchScores(m, activeTourney.bestOf);
      advanceWinnerInDraw(currentDraw, activeTourney.id, activeRoundIdx, idx, sim.winner, sim.scores);
    }
  });
  saveDraw();
  renderMatches();
}

export function autoSimulateEntireTournament() {
  if (viewingYear < currentTourYear || activeTourney.completed) return;
  if (!currentDraw || currentDraw.length === 0) {
    generateRealisticDraw();
  }
  for (let r = 0; r < currentDraw.length; r++) {
    currentDraw[r].forEach((m, idx) => {
      if (!m.winner && m.p1 && m.p2) {
        const sim = computeSimMatchScores(m, activeTourney.bestOf);
        advanceWinnerInDraw(currentDraw, activeTourney.id, r, idx, sim.winner, sim.scores);
      }
    });
  }
  activeRoundIdx = currentDraw.length - 1;
  saveDraw();
  renderRoundTabs();
  renderMatches();
}

// --- 5. ЗАВЕРШЕНИЕ ТУРНИРА, НАЧИСЛЕНИЕ ОЧКОВ И СРЕЗЫ ТОП-50 ---
export function finishTournamentAndAwardPoints() {
  if (!activeTourney || viewingYear < currentTourYear) return;
  if (activeTourney.completed) {
    showToast('⚠️ Этот турнир уже завершен в текущем сезоне! Повторное начисление очков заблокировано.');
    return;
  }
  if (!currentDraw || currentDraw.length === 0) {
    showToast('⚠️ Сетка турнира пуста! Сначала проведите жеребьевку.');
    return;
  }
  const finalMatch = currentDraw[currentDraw.length - 1][0];
  if (!finalMatch || !finalMatch.winner) {
    showToast('⚠️ Финал турнира еще не сыгран! Завершите все раунды перед начислением очков.');
    return;
  }

  // МГНОВЕННАЯ БЛОКИРОВКА КНОПКИ «ЗАВЕРШИТЬ ТУРНИР» (исключает задвоение очков)
  activeTourney.completed = true;
  const btnFinish = document.getElementById('btnFinishTourney');
  if (btnFinish) {
    btnFinish.disabled = true;
    btnFinish.innerText = 'Турнир завершен ✅';
  }

  const { participantsList } = applyTournamentPointsToPlayers(players, activeTourney, currentDraw, viewingYear);

  // Параллельный фоновый турнир ATP 250
  let bgReport = '';
  const currentIndex = tournaments.findIndex(t => t.id === activeTourney.id);
  if (activeTourney.type !== 'Итоговый') {
    bgReport = runBackgroundATP250Tournaments(players, participantsList, viewingYear, currentIndex);
    if (bgReport) {
      localStorage.setItem(`bg250_${activeTourney.id}_${viewingYear}`, bgReport);
      const bgBox = document.getElementById('bg250Notice');
      if (bgBox) {
        bgBox.style.display = 'block';
        bgBox.innerHTML = bgReport;
      }
    }
  }

  activeTourney.lastWinner = { ...finalMatch.winner };
  activeTourney.lastRunnerUp = finalMatch.p1.id === finalMatch.winner.id ? { ...finalMatch.p2 } : { ...finalMatch.p1 };
  activeTourney.lastScore = finalMatch.score ? finalMatch.score.join(' ') : 'W/O';

  saveTournaments();
  savePlayers(true);

  // Сохранение результатов в сезонный архив
  if (!seasonsHistory[viewingYear]) {
    seasonsHistory[viewingYear] = {
      year: viewingYear,
      slamSnapshots: {},
      tournamentsData: []
    };
  }
  if (!seasonsHistory[viewingYear].slamSnapshots) {
    seasonsHistory[viewingYear].slamSnapshots = {};
  }

  // Обновляем запись о турнире в архиве текущего года
  const existingTourneysData = seasonsHistory[viewingYear].tournamentsData || [];
  const tEntry = {
    id: activeTourney.id,
    name: activeTourney.name,
    type: activeTourney.type,
    surface: activeTourney.surface,
    winner: activeTourney.lastWinner,
    runnerUp: activeTourney.lastRunnerUp,
    score: activeTourney.lastScore
  };
  const existingIdx = existingTourneysData.findIndex(x => x.id === activeTourney.id);
  if (existingIdx >= 0) existingTourneysData[existingIdx] = tEntry;
  else existingTourneysData.push(tEntry);
  seasonsHistory[viewingYear].tournamentsData = existingTourneysData;
  seasonsHistory[viewingYear].worldNumberOne = { ...players[0] };

  // Если сыгран ТБШ — делаем автоматический срез Топ-50 со сравнением динамики относительно предыдущего Шлема/начала сезона
  if (activeTourney.type === 'ТБШ') {
    const slamOrder = ['tbsh_1', 'tbsh_2', 'tbsh_3', 'tbsh_4'];
    const sIdx = slamOrder.indexOf(activeTourney.id);
    let prevSnapList = null;
    if (sIdx > 0) {
      const prevSlamId = slamOrder[sIdx - 1];
      prevSnapList = seasonsHistory[viewingYear].slamSnapshots[prevSlamId]?.top50 || null;
    }
    if (!prevSnapList) {
      prevSnapList = seasonsHistory[viewingYear - 1]?.yearEndTop50 || null;
    }

    seasonsHistory[viewingYear].slamSnapshots[activeTourney.id] = {
      tourneyName: activeTourney.name,
      date: currentTourDateStr,
      top50: createTop50Snapshot(players, currentTourDateStr, prevSnapList)
    };
  }

  saveHistory();

  // Продвигаем календарную дату тура к следующему турниру
  if (currentIndex < tournaments.length - 1) {
    const nextTourney = tournaments[currentIndex + 1];
    const nextStartMonth = String(nextTourney.startMonth + 1).padStart(2, '0');
    const nextStartDay = String(nextTourney.startDay).padStart(2, '0');
    currentTourDateStr = `${currentTourYear}-${nextStartMonth}-${nextStartDay}`;
  } else {
    currentTourDateStr = `${currentTourYear}-11-25`;
  }

  saveDate();
  initUI();
  renderPlayersTable();
  renderRaceTable();

  showToast(`🏆 <b>${activeTourney.name}</b> завершен! Чемпион: <b>${finalMatch.winner.name}</b>. Рейтинг 52 недель и Гонка обновлены.`);
}

// --- 6. ЗАВЕРШЕНИЕ СЕЗОНА, ПЕНСИЯ ВЕТЕРАНОВ И ГЕНЕРАЦИЯ НЬЮГЕНОВ ---
export function endSeasonAndDecayPoints() {
  const endingYear = currentTourYear;

  if (!seasonsHistory[endingYear]) {
    seasonsHistory[endingYear] = { year: endingYear, slamSnapshots: {}, tournamentsData: [] };
  }

  // Предыдущий снимок для динамики итогового Топ-50
  const prevSnap =
    seasonsHistory[endingYear].slamSnapshots?.tbsh_4?.top50 ||
    seasonsHistory[endingYear - 1]?.yearEndTop50 ||
    null;

  seasonsHistory[endingYear].year = endingYear;
  seasonsHistory[endingYear].worldNumberOne = { ...players[0] };
  seasonsHistory[endingYear].yearEndTop50 = createTop50Snapshot(players, `${endingYear}-11-25`, prevSnap);
  seasonsHistory[endingYear].tournamentsData = tournaments.map(t => ({
    id: t.id,
    name: t.name,
    type: t.type,
    surface: t.surface,
    winner: t.lastWinner || null,
    runnerUp: t.lastRunnerUp || null,
    score: t.lastScore || '—'
  }));
  saveHistory();

  // ЗАПУСК СИСТЕМЫ ЗАВЕРШЕНИЯ КАРЬЕРЫ И ГЕНЕРАЦИИ МОЛОДЫХ НОВИЧКОВ (НЬЮГЕНОВ)
  const { updatedPlayers, retiredThisYear, newgensThisYear } = processEndOfSeasonRetirements(
    players,
    endingYear,
    retiredLegends
  );

  players = updatedPlayers;
  retiredLegends = [...retiredThisYear, ...retiredLegends];
  saveRetiredLegends();

  // Переход в новый сезон
  currentTourYear++;
  viewingYear = currentTourYear;
  currentTourDateStr = `${currentTourYear}-01-02`;
  activeTourney = tournaments[0];
  activeTourneyId = activeTourney.id;

  // Обнуляем Чемпионскую гонку (Live Race) 1 января и фиксируем стартовый ранг сезона
  sortAndRankPlayers(players, false);
  players.forEach(p => {
    p.racePoints = 0;
    p.seasonStartRank = p.rank;
    p.rankChange = 0;
  });

  tournaments.forEach(t => {
    t.completed = false;
    t.lastWinner = null;
    t.lastRunnerUp = null;
    t.lastScore = null;
  });

  savePlayers(false);
  saveTournaments();
  saveDate();
  initUI();
  renderPlayersTable();
  renderRaceTable();

  // Отображаем модальное окно / отчет смены поколений
  openSeasonTransitionReportModal(endingYear, currentTourYear, retiredThisYear, newgensThisYear);
}

function openSeasonTransitionReportModal(endedYear, newYear, retiredList, newgensList) {
  document.getElementById('seasonTransitionTitle').innerText = `Сезон ${endedYear} завершен · Добро пожаловать в сезон ${newYear}!`;
  document.getElementById('seasonTransitionSubtitle').innerText =
    `Архив сезона ${endedYear} сохранен в Зале Славы. Чемпионская гонка (Live Race) обнулена к 1 января ${newYear} года. Баланс пула: 300 игроков.`;

  const retiredHtml = retiredList.length === 0
    ? `<div style="padding: 16px; color: var(--text-dim); text-align: center;">В этом межсезонье никто из ветеранов не завершил карьеру.</div>`
    : retiredList.map(r => `
        <div class="h2h-item" style="flex-direction: column; align-items: flex-start; gap: 3px;">
          <div style="display: flex; justify-content: space-between; width: 100%;">
            <b>${r.flag} ${r.name}</b>
            <span style="color: var(--gold); font-weight: 700;">${r.retiredAge} лет</span>
          </div>
          <div style="font-size: 11.5px; color: var(--text-dim);">
            Наивысший рейтинг: <b style="color: var(--text-main);">#${r.bestRank}</b> · Финальный ранг: #${r.finalRank} · Сыграно сезонов: <b>${r.seasonsPlayed}</b>
          </div>
        </div>
      `).join('');

  const newgensHtml = newgensList.length === 0
    ? `<div style="padding: 16px; color: var(--text-dim); text-align: center;">Новые игроки не призывались.</div>`
    : newgensList.map(ng => `
        <div class="h2h-item" style="flex-direction: column; align-items: flex-start; gap: 3px;">
          <div style="display: flex; justify-content: space-between; width: 100%;">
            <b>${ng.flag} ${ng.name}</b>
            <span style="color: var(--primary); font-weight: 700;">${ng.ageAtEntry} лет</span>
          </div>
          <div style="font-size: 11.5px; color: var(--text-dim);">
            Дата рожд.: ${ng.birthDate} · Стартовые очки ATP: <b style="color: var(--accent);">${ng.points} pts</b>
          </div>
        </div>
      `).join('');

  document.getElementById('seasonTransitionBody').innerHTML = `
    <div class="report-columns">
      <div style="background: #0d1420; border: 1px solid var(--border); border-radius: 8px; padding: 14px;">
        <h4 style="color: var(--gold); font-size: 14px; margin-bottom: 10px;">👋 Завершили карьеру (${retiredList.length})</h4>
        <div style="max-height: 300px; overflow-y: auto;">
          ${retiredHtml}
        </div>
      </div>
      <div style="background: #0d1420; border: 1px solid var(--border); border-radius: 8px; padding: 14px;">
        <h4 style="color: var(--primary); font-size: 14px; margin-bottom: 10px;">🌟 Прибывшие молодые таланты — Ньюгены (${newgensList.length})</h4>
        <div style="max-height: 300px; overflow-y: auto;">
          ${newgensHtml}
        </div>
      </div>
    </div>
  `;

  document.getElementById('seasonTransitionModal').classList.add('open');
}

// --- 7. ТАБЛИЦЫ РЕЙТИНГА (52 НЕДЕЛИ), ГОНКИ И КАЛЕНДАРЯ ---
function renderRankChangeBadge(diff) {
  if (diff > 0) return `<span style="color: #10b981; font-size: 11.5px; font-weight: 700;">▲ +${diff}</span>`;
  if (diff < 0) return `<span style="color: #ef4444; font-size: 11.5px; font-weight: 700;">▼ ${diff}</span>`;
  return `<span style="color: var(--text-dim); font-size: 11.5px;">— 0</span>`;
}

export function renderPlayersTable() {
  const tbody = document.getElementById('playersTableBody');
  if (!tbody) return;
  const search = (document.getElementById('playerSearch')?.value || '').toLowerCase();
  const filtered = players.filter(p => p.name.toLowerCase().includes(search) || p.flag.toLowerCase().includes(search));

  tbody.innerHTML = filtered.map(p => `
    <tr>
      <td>
        <div style="font-weight: 700; font-size: 14px;">#${p.rank}</div>
        <div>${renderRankChangeBadge(p.rankChange || 0)}</div>
      </td>
      <td><b>${p.flag}</b></td>
      <td>
        <b>${p.name}</b>
        ${p.isNewgen ? '<span style="color: var(--primary); font-size: 11px; margin-left: 6px;">· Newgen</span>' : ''}
      </td>
      <td style="color: var(--accent); font-weight: 700;">${calculateAge(p.birthDate, currentTourDateStr)}</td>
      <td style="color: var(--text-dim); font-size: 12.5px;">${p.birthDate || '—'}</td>
      <td style="color: var(--gold); font-size: 12.5px; font-weight: 600;">#${p.bestRank || p.rank}</td>
      <td><b style="color: #fff;">${p.points.toLocaleString()}</b> <small style="color: var(--text-dim);">pts</small></td>
      <td>
        <button type="button" class="btn-edit" onclick="openEditPlayerModal('${p.id}')">Ред.</button>
      </td>
    </tr>
  `).join('');
}

export function renderRaceTable() {
  const tbody = document.getElementById('raceTableBody');
  if (!tbody) return;
  const search = (document.getElementById('raceSearch')?.value || '').toLowerCase();

  const raceSorted = [...players].sort((a, b) => {
    const diff = (b.racePoints || 0) - (a.racePoints || 0);
    if (diff !== 0) return diff;
    return a.rank - b.rank;
  });

  const filtered = raceSorted.filter(p => p.name.toLowerCase().includes(search) || p.flag.toLowerCase().includes(search));

  tbody.innerHTML = filtered.map(p => {
    const raceRank = raceSorted.findIndex(x => x.id === p.id) + 1;
    let statusBadge = '';
    if (raceRank <= 8) {
      statusBadge = `<span style="color: var(--primary); font-weight: 700; font-size: 12.5px;">Квалификация Топ-8 (#${raceRank})</span>`;
    } else if (raceRank <= 10) {
      statusBadge = `<span style="color: var(--gold); font-size: 12px;">Запасной (#${raceRank})</span>`;
    } else {
      statusBadge = `<span style="color: var(--text-dim); font-size: 12px;">Претендент</span>`;
    }

    return `
      <tr style="${raceRank <= 8 ? 'background: rgba(16, 185, 129, 0.06);' : ''}">
        <td><b>#${raceRank}</b></td>
        <td><b>${p.flag}</b></td>
        <td><b>${p.name}</b></td>
        <td style="color: var(--accent);">${calculateAge(p.birthDate, currentTourDateStr)}</td>
        <td><b style="color: var(--gold); font-size: 14.5px;">${(p.racePoints || 0).toLocaleString()}</b> <small style="color: var(--text-dim);">pts</small></td>
        <td>${statusBadge}</td>
      </tr>
    `;
  }).join('');
}

export function renderCalendarTable() {
  const tbody = document.getElementById('calendarTableBody');
  if (!tbody) return;
  const selectedYear = parseInt(document.getElementById('calendarYearSelect')?.value, 10) || currentTourYear;

  const histTourneys = seasonsHistory[selectedYear]?.tournamentsData || [];

  tbody.innerHTML = tournaments.map((t, idx) => {
    const dateRange = getTourneyDateRange(t, selectedYear);
    const isCurrent = (selectedYear === currentTourYear && activeTourney && t.id === activeTourney.id);
    const histEntry = histTourneys.find(h => h.id === t.id);

    let drawExists = false;
    let drawWinner = null;
    try {
      const savedD = JSON.parse(localStorage.getItem(`draw_${t.id}_${selectedYear}`));
      if (savedD && savedD.length > 0 && savedD[savedD.length - 1][0]?.winner) {
        drawExists = true;
        drawWinner = savedD[savedD.length - 1][0].winner;
      }
    } catch {
      drawExists = false;
    }

    const isDone = (selectedYear < currentTourYear && (histEntry?.winner || drawExists)) ||
                   (selectedYear === currentTourYear && t.completed);

    const champName = (selectedYear === currentTourYear && t.lastWinner)
      ? `${t.lastWinner.flag} ${t.lastWinner.name}`
      : (histEntry?.winner ? `${histEntry.winner.flag} ${histEntry.winner.name}` : (drawWinner ? `${drawWinner.flag} ${drawWinner.name}` : ''));

    const statusBadge = isDone
      ? `<span style="color: var(--primary); font-weight: 600;">Завершен ✅ ${champName ? '· 🏆 ' + champName : ''}</span>`
      : (isCurrent ? `<span style="color: var(--gold); font-weight: 700;">Активный турнир 🎾</span>` : `<span style="color: var(--text-dim);">По расписанию</span>`);

    let tierClass = 'tier-text-1000';
    if (t.type === 'ТБШ') tierClass = 'tier-text-slam';
    else if (t.type === 'ATP 500') tierClass = 'tier-text-500';
    else if (t.type === 'Итоговый') tierClass = 'tier-text-finals';

    return `
      <tr class="${isCurrent ? 'active-tourney-row' : ''}">
        <td><b>#${idx + 1}</b></td>
        <td style="color: var(--accent); font-family: 'JetBrains Mono', monospace; font-size: 12.5px;">${dateRange}</td>
        <td><span class="${tierClass}">${t.type}</span></td>
        <td><b>${t.name}</b></td>
        <td><span class="${getSurfaceTextClass(t.surface)}">${t.surface}</span></td>
        <td>${t.size} игр.</td>
        <td>${statusBadge}</td>
        <td style="display: flex; gap: 6px;">
          <button type="button" onclick="jumpToTourney('${t.id}', ${selectedYear})">Открыть сетку</button>
          <button type="button" class="btn-edit" onclick="openEditTourneyModal('${t.id}')">Ред.</button>
        </td>
      </tr>
    `;
  }).join('');
}

export function jumpToTourney(tourneyId, year = null) {
  if (year) {
    viewingYear = parseInt(year, 10);
    const drawYearSel = document.getElementById('drawYearSelect');
    if (drawYearSel) {
      // Если года еще нет в селекте, добавим его
      if (!Array.from(drawYearSel.options).some(o => parseInt(o.value, 10) === viewingYear)) {
        const opt = document.createElement('option');
        opt.value = String(viewingYear);
        opt.textContent = `Сезон ${viewingYear} (Архив)`;
        drawYearSel.appendChild(opt);
      }
      drawYearSel.value = String(viewingYear);
    }
  }
  const tSelect = document.getElementById('tourneySelect');
  if (tSelect) {
    tSelect.innerHTML = tournaments.map((t, idx) => `
      <option value="${t.id}" ${t.id === tourneyId ? 'selected' : ''}>
        #${idx + 1} ${t.name} (${t.type} · ${t.surface}) [${getTourneyDateRange(t, viewingYear)}]
      </option>
    `).join('');
    tSelect.value = tourneyId;
  }
  loadCurrentTourney();
  switchTab('tourney');
}

// --- 8. МОДАЛКИ РЕДАКТИРОВАНИЯ ИГРОКОВ И ТУРНИРОВ ---
export function openEditPlayerModal(id) {
  const p = players.find(x => x.id === id);
  if (!p) return;
  document.getElementById('editPlayerId').value = p.id;
  document.getElementById('editPlayerName').value = p.name;
  document.getElementById('editPlayerFlag').value = p.flag;
  document.getElementById('editPlayerBirth').value = p.birthDate || '2000-01-01';
  document.getElementById('editPlayerPoints').value = p.points;
  document.getElementById('editPlayerModal').classList.add('open');
}

export function savePlayerEdit() {
  const id = document.getElementById('editPlayerId').value;
  const p = players.find(x => x.id === id);
  if (p) {
    const newName = document.getElementById('editPlayerName').value.trim();
    const newFlag = document.getElementById('editPlayerFlag').value.trim();
    if (newName && !/\d/.test(newName)) p.name = newName;
    if (newFlag) p.flag = newFlag.toUpperCase();
    p.birthDate = document.getElementById('editPlayerBirth').value || p.birthDate;
    savePlayers(false);
    renderPlayersTable();
    renderRaceTable();
    closeModal('editPlayerModal');
    showToast(`✅ Данные игрока <b>${p.name}</b> обновлены.`);
  }
}

export function openAddPlayerModal() {
  document.getElementById('newPlayerName').value = '';
  document.getElementById('newPlayerFlag').value = 'USA';
  document.getElementById('newPlayerBirth').value = '2003-05-15';
  const errEl = document.getElementById('addPlayerError');
  if (errEl) errEl.style.display = 'none';
  document.getElementById('addPlayerModal').classList.add('open');
}

export function confirmAddPlayer() {
  const name = document.getElementById('newPlayerName').value.trim();
  const country = (document.getElementById('newPlayerFlag').value.trim() || 'USA').toUpperCase();
  const birth = document.getElementById('newPlayerBirth').value || '2003-05-15';
  const errEl = document.getElementById('addPlayerError');

  if (!name || /\d/.test(name)) {
    if (errEl) {
      errEl.innerText = 'Введите корректное имя и фамилию на латинице без цифр.';
      errEl.style.display = 'block';
    }
    return;
  }

  players.push({
    id: 'p_custom_' + Date.now(),
    rank: players.length + 1,
    name,
    flag: country,
    points: 25,
    racePoints: 0,
    birthDate: birth,
    tournamentPoints: {},
    rankChange: 0,
    bestRank: players.length + 1,
    seasonsPlayed: 1
  });

  savePlayers(false);
  renderPlayersTable();
  renderRaceTable();
  closeModal('addPlayerModal');
  showToast(`✅ Игрок <b>${name} (${country})</b> добавлен в тур.`);
}

export function openEditTourneyModal(id) {
  const t = tournaments.find(x => x.id === id);
  if (!t) return;
  document.getElementById('editTourneyId').value = t.id;
  document.getElementById('editTourneyName').value = t.name;
  document.getElementById('editTourneySurface').value = t.surface;
  document.getElementById('editTourneyModal').classList.add('open');
}

export function openEditCurrentTourney() {
  if (activeTourney) openEditTourneyModal(activeTourney.id);
}

export function saveTourneyEdit() {
  const id = document.getElementById('editTourneyId').value;
  const t = tournaments.find(x => x.id === id);
  if (t) {
    const newName = document.getElementById('editTourneyName').value.trim();
    const newSurface = document.getElementById('editTourneySurface').value;
    if (newName) t.name = newName;
    if (newSurface) t.surface = newSurface;
    saveTournaments();
    initUI();
    closeModal('editTourneyModal');
    showToast(`✅ Турнир <b>${t.name}</b> обновлен.`);
  }
}

export function openPointsInfoModal() {
  document.getElementById('pointsInfoModal').classList.add('open');
}

// --- 9. ПОЛНЫЙ РЕДИЗАЙН ЗАЛА СЛАВЫ (АРХИВ СЕЗОНОВ, 5 СРЕЗОВ ТОП-50 И ЛЕГЕНДЫ ТУРА) ---
export function switchHallSubtab(subtab) {
  activeHallSubtab = subtab;
  const btnArch = document.getElementById('subtab-archive-btn');
  const btnLeg = document.getElementById('subtab-legends-btn');
  const contentArch = document.getElementById('historyContent');
  const contentLeg = document.getElementById('legendsContent');
  const pickerWrap = document.getElementById('historyYearPickerWrap');

  if (subtab === 'legends') {
    btnArch.classList.remove('active');
    btnLeg.classList.add('active');
    contentArch.style.display = 'none';
    contentLeg.style.display = 'block';
    pickerWrap.style.display = 'none';
    renderLegendsTab();
  } else {
    btnLeg.classList.remove('active');
    btnArch.classList.add('active');
    contentLeg.style.display = 'none';
    contentArch.style.display = 'block';
    pickerWrap.style.display = 'flex';
    renderHistoryYear();
  }
}

export function initHistoryUI() {
  const select = document.getElementById('historyYearSelect');
  if (!select) return;
  const years = Object.keys(seasonsHistory).sort((a, b) => Number(b) - Number(a));
  if (years.length === 0) {
    select.innerHTML = '<option value="">Нет архивных сезонов</option>';
    document.getElementById('historyContent').innerHTML =
      '<div style="color: var(--text-dim); padding: 30px; text-align: center;">Завершите сезон, чтобы здесь появился архив!</div>';
    return;
  }
  const currentSelected = select.value && years.includes(select.value) ? select.value : years[0];
  select.innerHTML = years.map(y => `<option value="${y}" ${y === currentSelected ? 'selected' : ''}>Сезон ${y}</option>`).join('');
  if (activeHallSubtab === 'legends') {
    renderLegendsTab();
  } else {
    renderHistoryYear();
  }
}

export function setSnapshotKey(key) {
  activeSnapshotKey = key;
  renderHistoryYear();
}

export function setCompareMode(mode) {
  activeCompareMode = mode;
  renderHistoryYear();
}

export function renderHistoryYear() {
  const year = document.getElementById('historyYearSelect')?.value;
  const data = seasonsHistory[year];
  const container = document.getElementById('historyContent');
  if (!container || !data) return;

  const slamSnaps = data.slamSnapshots || {};
  const yearEnd50 = data.yearEndTop50 || (data.top10 ? data.top10 : []);
  const start50 = data.seasonStartTop50 || seasonsHistory[Number(year) - 1]?.yearEndTop50 || [];

  let activeList = [];
  let activeTitle = '';
  let prevRefList = start50;

  if (activeSnapshotKey === 'yearEnd') {
    activeList = yearEnd50;
    activeTitle = `Итоговый Топ-50 сезона ${year} года`;
    prevRefList = activeCompareMode === 'start' ? start50 : (slamSnaps['tbsh_4']?.top50 || start50);
  } else if (slamSnaps[activeSnapshotKey]) {
    activeList = slamSnaps[activeSnapshotKey].top50 || [];
    activeTitle = `Срез Топ-50 после ${slamSnaps[activeSnapshotKey].tourneyName} (${slamSnaps[activeSnapshotKey].date})`;
    const slamOrder = ['tbsh_1', 'tbsh_2', 'tbsh_3', 'tbsh_4'];
    const idx = slamOrder.indexOf(activeSnapshotKey);
    if (activeCompareMode === 'start' || idx <= 0) {
      prevRefList = start50;
    } else {
      prevRefList = slamSnaps[slamOrder[idx - 1]]?.top50 || start50;
    }
  }

  const refRankMap = {};
  (prevRefList || []).forEach(p => {
    if (p && p.id) refRankMap[p.id] = p.rank;
    else if (p && p.name) refRankMap[p.name] = p.rank;
  });

  const comparisonLabel = activeCompareMode === 'start'
    ? 'Динамика (к началу года)'
    : 'Динамика (к пред. Шлему)';

  // Полный список из 26 турниров для таблицы чемпионов года
  const savedTourneysMap = {};
  (data.tournamentsData || []).forEach(t => { savedTourneysMap[t.id] = t; });

  const full26List = (tournaments || FULL_CALENDAR_TEMPLATE).map(tmpl => {
    const saved = savedTourneysMap[tmpl.id];
    if (saved && saved.winner) return saved;
    try {
      const d = JSON.parse(localStorage.getItem(`draw_${tmpl.id}_${year}`));
      if (d && d.length > 0 && d[d.length - 1][0]?.winner) {
        const fm = d[d.length - 1][0];
        const w = fm.winner;
        const ru = (fm.p1 && fm.p2) ? (fm.p1.id === w.id ? fm.p2 : fm.p1) : null;
        return {
          id: tmpl.id,
          name: tmpl.name,
          type: tmpl.type,
          surface: tmpl.surface,
          winner: w,
          runnerUp: ru,
          score: fm.score ? fm.score.join(' ') : '6-4 6-4'
        };
      }
    } catch {
      // ignore
    }
    return saved || {
      id: tmpl.id,
      name: tmpl.name,
      type: tmpl.type,
      surface: tmpl.surface,
      winner: null,
      runnerUp: null,
      score: '—'
    };
  });

  const worldNo1 = data.worldNumberOne || activeList[0] || players[0];

  const html = `
    <div class="history-card" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
      <div>
        <div style="font-size: 12px; color: var(--gold); font-weight: 700;">ПЕРВАЯ РАКЕТКА МИРА ПО ИТОГАМ ${year} ГОДА</div>
        <div style="font-size: 21px; font-weight: 800; margin-top: 4px;">${worldNo1.flag} ${worldNo1.name}</div>
      </div>
      <div style="text-align: right;">
        <div style="font-size: 12px; color: var(--text-dim);">Итоговые очки 52 недель:</div>
        <div style="font-size: 19px; color: var(--accent); font-weight: 800;">${(worldNo1.points || 0).toLocaleString()} pts</div>
      </div>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 10px; margin-top: 16px;">
      <div>
        <h3 style="font-size: 16px; margin-bottom: 4px;">📊 Снимки Рейтинга Топ-50 за ${year} год</h3>
        <small style="color: var(--text-dim);">Переключайтесь между срезами после каждого ТБШ и итоговым рейтингом сезона:</small>
      </div>
      <div style="display: flex; gap: 6px; align-items: center;">
        <span style="font-size: 12px; color: var(--text-dim);">Сравнение динамики:</span>
        <button type="button" class="btn-edit" style="${activeCompareMode === 'prev' ? 'border-color: var(--accent); color: var(--accent);' : ''}" onclick="setCompareMode('prev')">К пред. Шлему</button>
        <button type="button" class="btn-edit" style="${activeCompareMode === 'start' ? 'border-color: var(--accent); color: var(--accent);' : ''}" onclick="setCompareMode('start')">К началу года</button>
      </div>
    </div>

    <div class="snapshot-tabs" role="tablist" aria-label="Снимки Топ-50 сезона">
      <button type="button" class="snapshot-btn ${activeSnapshotKey === 'tbsh_1' ? 'active' : ''}" onclick="setSnapshotKey('tbsh_1')">Срез Топ-50 после 1-го ТБШ</button>
      <button type="button" class="snapshot-btn ${activeSnapshotKey === 'tbsh_2' ? 'active' : ''}" onclick="setSnapshotKey('tbsh_2')">Срез Топ-50 после 2-го ТБШ</button>
      <button type="button" class="snapshot-btn ${activeSnapshotKey === 'tbsh_3' ? 'active' : ''}" onclick="setSnapshotKey('tbsh_3')">Срез Топ-50 после 3-го ТБШ</button>
      <button type="button" class="snapshot-btn ${activeSnapshotKey === 'tbsh_4' ? 'active' : ''}" onclick="setSnapshotKey('tbsh_4')">Срез Топ-50 после 4-го ТБШ</button>
      <button type="button" class="snapshot-btn ${activeSnapshotKey === 'yearEnd' ? 'active' : ''}" onclick="setSnapshotKey('yearEnd')">Итоговый Топ-50 сезона</button>
    </div>

    <div style="font-size: 14px; font-weight: 700; color: var(--accent); margin-bottom: 10px;">${activeTitle}</div>

    ${activeList.length === 0 ? `
      <div style="padding: 24px; color: var(--text-dim); text-align: center; border: 1px dashed var(--border); border-radius: 8px; margin-bottom: 24px;">
        Срез для этого турнира Большого Шлема появится автоматически сразу после завершения турнира в сезоне ${year}.
      </div>
    ` : `
      <div style="max-height: 420px; overflow-y: auto; margin-bottom: 28px;">
        <table class="custom-table">
          <thead>
            <tr>
              <th style="width: 75px;">Ранг</th>
              <th style="width: 195px;">${comparisonLabel}</th>
              <th style="width: 80px;">Страна</th>
              <th>Игрок</th>
              <th style="width: 100px;">Возраст</th>
              <th>Очки ATP</th>
            </tr>
          </thead>
          <tbody>
            ${activeList.map(p => {
              const refRank = refRankMap[p.id] || refRankMap[p.name];
              const delta = refRank !== undefined ? (refRank - p.rank) : (p.rankDelta || 0);
              return `
                <tr>
                  <td><b>#${p.rank}</b></td>
                  <td>${renderRankChangeBadge(delta)}</td>
                  <td><b>${p.flag}</b></td>
                  <td><b>${p.name}</b></td>
                  <td style="color: var(--accent);">${p.age || calculateAge(p.birthDate, `${year}-06-15`)}</td>
                  <td><b>${(p.points || 0).toLocaleString()}</b> <small style="color:var(--text-dim);">pts</small></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `}

    <h3 style="margin: 18px 0 10px 0; font-size: 16px;">🏆 Таблица чемпионов всех 26 турниров сезона ${year}</h3>
    <div style="max-height: 520px; overflow-y: auto;">
      <table class="custom-table">
        <thead>
          <tr>
            <th style="width: 50px;">№</th>
            <th>Турнир</th>
            <th>Категория</th>
            <th>Покрытие</th>
            <th>Чемпион</th>
            <th>Финалист</th>
            <th>Счет финала</th>
            <th style="width: 140px;">Историческая сетка</th>
          </tr>
        </thead>
        <tbody>
          ${full26List.map((t, idx) => `
            <tr>
              <td><b>#${idx + 1}</b></td>
              <td><b>${t.name}</b></td>
              <td>${t.type}</td>
              <td><span class="${getSurfaceTextClass(t.surface)}">${t.surface}</span></td>
              <td style="color: var(--primary); font-weight: 700;">${t.winner ? t.winner.flag + ' ' + t.winner.name : '—'}</td>
              <td style="color: var(--text-dim);">${t.runnerUp ? t.runnerUp.flag + ' ' + t.runnerUp.name : '—'}</td>
              <td class="match-score">${t.score && t.score !== '—' ? formatTennisScore(t.score.split(' ')) : '—'}</td>
              <td>
                <button type="button" onclick="jumpToTourney('${t.id}', ${year})">🔍 Вся сетка</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  container.innerHTML = html;
}

export function renderLegendsTab() {
  const container = document.getElementById('legendsContent');
  if (!container) return;

  if (!retiredLegends || retiredLegends.length === 0) {
    container.innerHTML = `
      <div class="history-card" style="text-align: center; padding: 40px 20px;">
        <h3 style="font-size: 17px; color: var(--gold); margin-bottom: 8px;">Зал Славы: Завершившие карьеру (Легенды тура)</h3>
        <p style="color: var(--text-dim); font-size: 13.5px; max-width: 560px; margin: 0 auto;">
          Когда возрастные игроки (37–42 лет) завершают профессиональную карьеру по окончании сезона, их именные карточки с пиковым рейтингом и количеством сезонов бережно сохраняются здесь.
        </p>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div style="margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h3 style="font-size: 17px; color: var(--gold);">Завершившие карьеру (Легенды тура) · ${retiredLegends.length} игр.</h3>
        <small style="color: var(--text-dim);">Почетный архив ветеранов, повесивших ракетку на гвоздь по итогам прошлых сезонов.</small>
      </div>
    </div>
    <div class="legends-grid">
      ${retiredLegends.map(leg => `
        <div class="legend-card">
          <div class="legend-card-header">
            <span class="legend-name">${leg.flag} ${leg.name}</span>
            <span style="color: var(--gold); font-size: 12px; font-weight: 700;">Выпуск ${leg.retiredYear}</span>
          </div>
          <div class="legend-meta">
            Возраст ухода: <b style="color: var(--text-main);">${leg.retiredAge} лет</b> (${leg.birthDate || '—'})
          </div>
          <div class="legend-meta">
            Наивысший рейтинг в карьере: <b style="color: var(--primary);">#${leg.bestRank}</b>
          </div>
          <div class="legend-meta">
            Финальный рейтинг: <b>#${leg.finalRank}</b> · Сыграно сезонов: <b>${leg.seasonsPlayed}</b>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

// --- 10. ПЕРЕКЛЮЧЕНИЕ ВКЛАДОК И МОДАЛОК ---
export function switchTab(tabId) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

  const targetPanel = document.getElementById(`tab-${tabId}`);
  const targetBtn = document.getElementById(`nav-${tabId}`);
  if (targetPanel) targetPanel.classList.add('active');
  if (targetBtn) targetBtn.classList.add('active');

  if (tabId === 'players') {
    renderPlayersTable();
  } else if (tabId === 'race') {
    renderRaceTable();
  } else if (tabId === 'calendar') {
    renderCalendarTable();
  } else if (tabId === 'history') {
    initHistoryUI();
  }
}

export function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
  if (id === 'scoreModal') {
    activeMatchScore = null;
  }
}

// Экспорт обработчиков в window для inline-вызовов из index.html
if (typeof window !== 'undefined') {
  window.switchTab = switchTab;
  window.changeDrawYear = changeDrawYear;
  window.loadCurrentTourney = loadCurrentTourney;
  window.openPointsInfoModal = openPointsInfoModal;
  window.openEditCurrentTourney = openEditCurrentTourney;
  window.openEditTourneyModal = openEditTourneyModal;
  window.saveTourneyEdit = saveTourneyEdit;
  window.generateRealisticDraw = generateRealisticDraw;
  window.autoSimulateRound = autoSimulateRound;
  window.autoSimulateEntireTournament = autoSimulateEntireTournament;
  window.finishTournamentAndAwardPoints = finishTournamentAndAwardPoints;
  window.resetCurrentDraw = resetCurrentDraw;
  window.changeRound = changeRound;
  window.openScoreModal = openScoreModal;
  window.appendSetScore = appendSetScore;
  window.clearScoreInput = clearScoreInput;
  window.generateRandomScoreToInput = generateRandomScoreToInput;
  window.instantSimulateMatch = instantSimulateMatch;
  window.quickApplyWinner = quickApplyWinner;
  window.saveQuickStringScore = saveQuickStringScore;
  window.renderPlayersTable = renderPlayersTable;
  window.renderRaceTable = renderRaceTable;
  window.renderCalendarTable = renderCalendarTable;
  window.jumpToTourney = jumpToTourney;
  window.openAddPlayerModal = openAddPlayerModal;
  window.confirmAddPlayer = confirmAddPlayer;
  window.openEditPlayerModal = openEditPlayerModal;
  window.savePlayerEdit = savePlayerEdit;
  window.manualRepairPoints = manualRepairPoints;
  window.endSeasonAndDecayPoints = endSeasonAndDecayPoints;
  window.initHistoryUI = initHistoryUI;
  window.renderHistoryYear = renderHistoryYear;
  window.setSnapshotKey = setSnapshotKey;
  window.setCompareMode = setCompareMode;
  window.switchHallSubtab = switchHallSubtab;
  window.closeModal = closeModal;

  // Автозапуск при загрузке DOM
  initData();
  initUI();
}

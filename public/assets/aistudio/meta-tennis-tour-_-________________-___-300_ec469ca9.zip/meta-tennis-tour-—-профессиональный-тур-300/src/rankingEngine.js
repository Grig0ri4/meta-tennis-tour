/**
 * Meta Tennis Tour — Движок рейтинга, Чемпионской гонки, фоновых ATP 250 и снимков Топ-50 (rankingEngine.js)
 * Официальная шкала ATP 2024: ТБШ (2000..10), Мастерс (1000..10), ATP 500 (500..0), ATP 250 (250..25), Итоговый (до 1500).
 */

import { shuffleArray, calculateGroupStandings } from './drawEngine.js';
import { BG_250_NAMES } from '../data/tournaments.js';

export const POINTS_SCALE = {
  128: [10, 50, 100, 200, 400, 800, 1300, 2000], // ТБШ
  64: [10, 50, 100, 200, 400, 650, 1000],        // Мастерс
  32: [0, 50, 100, 200, 330, 500]                // ATP 500
};

export function calculateAgeNum(birthDateStr, currentDateStr) {
  if (!birthDateStr) return 24;
  const birth = new Date(birthDateStr);
  const current = new Date(currentDateStr || '2024-01-02');
  let age = current.getFullYear() - birth.getFullYear();
  const m = current.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && current.getDate() < birth.getDate())) age--;
  return age;
}

export function calculateAge(birthDateStr, currentDateStr) {
  if (!birthDateStr) return '—';
  return calculateAgeNum(birthDateStr, currentDateStr) + ' г.';
}

export function getDefendingPoints(player, tourneyId, year) {
  const prevYear = year - 1;
  if (player && player.tournamentPoints && player.tournamentPoints[tourneyId] && player.tournamentPoints[tourneyId][prevYear] !== undefined) {
    return player.tournamentPoints[tourneyId][prevYear];
  }
  return 0;
}

export function sortAndRankPlayers(players, updateRankChange = false) {
  const prevRanks = {};
  if (updateRankChange) {
    players.forEach(p => {
      prevRanks[p.id] = p.rank || 300;
    });
  }

  players.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    return (b.racePoints || 0) - (a.racePoints || 0);
  });

  players.forEach((p, idx) => {
    const newRank = idx + 1;
    if (updateRankChange && prevRanks[p.id] !== undefined) {
      p.rankChange = prevRanks[p.id] - newRank;
    } else if (p.rankChange === undefined) {
      p.rankChange = 0;
    }
    p.rank = newRank;
    if (!p.bestRank || newRank < p.bestRank) {
      p.bestRank = newRank;
    }
  });

  return players;
}

export function calculateTournamentEarnedPoints(tourney, draw) {
  const earnedMap = {};
  const participantsList = [];
  const finalMatch = draw[draw.length - 1][0];

  if (tourney.id === 'finals') {
    const groupAStats = calculateGroupStandings(draw[0]);
    const groupBStats = calculateGroupStandings(draw[1]);
    [...groupAStats, ...groupBStats].forEach(st => {
      earnedMap[st.player.id] = (st.wins * 200);
      participantsList.push(st.player);
    });

    if (draw[2] && draw[2][0] && draw[2][0].winner && draw[2][0].p1 && draw[2][0].p2) {
      const sfLoser1 = (draw[2][0].winner.id === draw[2][0].p1.id) ? draw[2][0].p2 : draw[2][0].p1;
      if (sfLoser1) earnedMap[sfLoser1.id] = (earnedMap[sfLoser1.id] || 0); // SF loser keeps group points
    }

    const finalWinner = finalMatch.winner;
    const finalRunnerUp = (finalMatch.p1.id === finalWinner.id) ? finalMatch.p2 : finalMatch.p1;
    // ATP Finals: +200 per RR win, +400 for SF win, +500 for Final win (up to 1500 undefeated)
    earnedMap[finalWinner.id] = (earnedMap[finalWinner.id] || 0) + 900;
    earnedMap[finalRunnerUp.id] = (earnedMap[finalRunnerUp.id] || 0) + 400;
  } else {
    const scale = POINTS_SCALE[tourney.size] || POINTS_SCALE[32];
    draw.forEach((round, rIdx) => {
      round.forEach(m => {
        if (m && m.winner && m.p1 && m.p2) {
          const loser = (m.p1.id === m.winner.id) ? m.p2 : m.p1;
          earnedMap[loser.id] = scale[rIdx];
          if (rIdx === 0) {
            participantsList.push(m.p1, m.p2);
          }
        }
      });
    });
    earnedMap[finalMatch.winner.id] = scale[scale.length - 1];
  }

  return { earnedMap, participantsList };
}

export function applyTournamentPointsToPlayers(players, tourney, draw, viewingYear) {
  const { earnedMap, participantsList } = calculateTournamentEarnedPoints(tourney, draw);

  players.forEach(p => {
    const earned = earnedMap[p.id] || 0;
    const defending = getDefendingPoints(p, tourney.id, viewingYear);
    const diff = earned - defending;

    p.points = Math.max(15, p.points + diff);
    p.racePoints = (p.racePoints || 0) + earned;

    if (!p.tournamentPoints) p.tournamentPoints = {};
    if (!p.tournamentPoints[tourney.id]) p.tournamentPoints[tourney.id] = {};
    p.tournamentPoints[tourney.id][viewingYear] = earned;
  });

  return { participantsList, earnedMap };
}

export function runBackgroundATP250Tournaments(players, mainTourneyParticipants, viewingYear, tourneyIndex = 0) {
  try {
    const participantIds = new Set(
      (mainTourneyParticipants || []).filter(p => p && p.id).map(p => p.id)
    );
    const available250 = players.filter(
      p => p && p.id && !participantIds.has(p.id) && p.rank >= 25 && p.rank <= 270
    );

    if (available250.length < 32) return "";

    const tName = BG_250_NAMES[tourneyIndex % BG_250_NAMES.length] || BG_250_NAMES[Math.floor(Math.random() * BG_250_NAMES.length)];
    const tourneyPool = shuffleArray(available250).slice(0, 32);

    const winner = tourneyPool[0];
    const finalist = tourneyPool[1];
    const sf1 = tourneyPool[2];
    const sf2 = tourneyPool[3];
    const qf = tourneyPool.slice(4, 8);
    const r16 = tourneyPool.slice(8, 16);

    function addPts(pl, pts) {
      if (!pl) return;
      const defending = getDefendingPoints(pl, `bg250_${tName}`, viewingYear);
      pl.points = Math.max(15, pl.points - defending + pts);
      pl.racePoints = (pl.racePoints || 0) + pts;
      if (!pl.tournamentPoints) pl.tournamentPoints = {};
      if (!pl.tournamentPoints[`bg250_${tName}`]) pl.tournamentPoints[`bg250_${tName}`] = {};
      pl.tournamentPoints[`bg250_${tName}`][viewingYear] = pts;
    }

    addPts(winner, 250);
    addPts(finalist, 165);
    addPts(sf1, 100);
    addPts(sf2, 100);
    qf.forEach(p => addPts(p, 50));
    r16.forEach(p => addPts(p, 25));

    return `🎾 <b>Параллельный фоновый турнир:</b> ${tName} (ATP 250) — Чемпион: <b>${winner.name}</b> (+250 pts) · Финалист: <b>${finalist.name}</b> (+165 pts) · Полуфинал: ${sf1.name}, ${sf2.name} (+100 pts) · 1/4: (+50 pts) · 1/8: (+25 pts)`;
  } catch (err) {
    console.warn("Background 250 error avoided:", err);
    return "";
  }
}

export function createTop50Snapshot(players, currentTourDateStr, prevSnapshotTop50 = null) {
  const prevRankMap = {};
  if (prevSnapshotTop50 && Array.isArray(prevSnapshotTop50)) {
    prevSnapshotTop50.forEach(p => {
      if (p && p.id) prevRankMap[p.id] = p.rank;
      else if (p && p.name) prevRankMap[p.name] = p.rank;
    });
  }

  return players.slice(0, 50).map(p => {
    const prevRank = prevRankMap[p.id] || prevRankMap[p.name] || p.seasonStartRank || p.rank;
    const rankDelta = prevRank - p.rank;
    return {
      id: p.id,
      rank: p.rank,
      name: p.name,
      flag: p.flag,
      points: p.points,
      birthDate: p.birthDate,
      age: calculateAge(p.birthDate, currentTourDateStr),
      rankDelta: rankDelta
    };
  });
}

if (typeof window !== 'undefined') {
  window.POINTS_SCALE = POINTS_SCALE;
  window.calculateAgeNum = calculateAgeNum;
  window.calculateAge = calculateAge;
  window.getDefendingPoints = getDefendingPoints;
  window.sortAndRankPlayers = sortAndRankPlayers;
  window.calculateTournamentEarnedPoints = calculateTournamentEarnedPoints;
  window.applyTournamentPointsToPlayers = applyTournamentPointsToPlayers;
  window.runBackgroundATP250Tournaments = runBackgroundATP250Tournaments;
  window.createTop50Snapshot = createTop50Snapshot;
}
